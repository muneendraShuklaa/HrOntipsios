import React, { Component } from 'react';
import { View, Text, TouchableOpacity, FlatList, StyleSheet,Image } from 'react-native';
import { WebView } from 'react-native-webview'
import utils from '../../../Utils';
import { Header } from "../../../Components/Header"
import { withMyHook } from "../../../Utils/Dark"
import { vh, vw, normalize } from '../../../Utils/dimentions';

import { SafeAreaView } from 'react-native-safe-area-context';

class announcement extends Component {
  constructor(props) {
    super(props)
    this.state = {
        cardDeatils: [
              
            {
                Name: 'Sick Leaves',
                title: '12',
            },
            {
                Name: 'Casual Leaves',
                title: '6',
            },
            {
                Name: 'Eaened Leaves',
                title: ' 2',
            },
        ]
     
    }
  }
  render() {
    return (
        <View style={{ flex: 1, backgroundColor: '#fff', }}>
        
 <FlatList
                                style={{ height:"100%" ,padding:10}}
                                showsHorizontalScrollIndicator={false}
                                data={this.state.cardDeatils}
                                keyExxtractor={(item, index) => index.toString}
                                renderItem={({ item, index }) => this.renderItem(item, index)}
                            />
                            






          

        </View>

    );
  }
  renderItem(item, index) {
    return (
        <View style={{ height: "auto", width: "98%", paddingBottom: vh(10), marginTop: vh(5), justifyContent: 'center', alignSelf: 'center' }}>
            <View style={styles.shadowView}>
                {/* <TouchableOpacity style={{alignSelf:'center'}} onPress={()=>{this.props.navigation.navigate("LiveLocation")}}> */}
                    
                    <View style={{ flexDirection:'row',justifyContent:'space-between'  }}>
                        <Text style={[styles.Title, utils.fontStyle.TextSemiBold,{marginLeft:15,color:utils.color.textColorheading }]}>Holiday</Text>
                        <Text style={[styles.Title, utils.fontStyle.FontFamilyRegular,{fontSize:14,marginRight:15, color:'grey',}]}>Dec 22,2023</Text>

                      
                    </View>
                    <Text style={[styles.Title, utils.fontStyle.FontFamilyRegular,{fontSize:14,marginLeft:15, color:'grey',}]}>Posted By - {item.Name}</Text>

                {/* </TouchableOpacity> */}
            </View>
        
        </View>

    )
}
}
export const Announcement = withMyHook(announcement)
const styles = StyleSheet.create({
    Title: {
        color: "#000",
    },
    shadowView: {
        height: vh(70), width: "100%", 
        borderRadius: 10,
        backgroundColor: '#fff', justifyContent:'center',
        shadowColor: "#000",
        shadowOffset: {
            width: 0,
            height: 2,
        },
        shadowOpacity: 0.23,
        shadowRadius: 2.62,
        elevation: 4,
    }
});
