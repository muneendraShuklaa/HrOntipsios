import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';
import Endpoint from '../../../Utils/Endpoint';
import moment from 'moment';

export default class RequestHelper {
  constructor(self) {
    this.self = self;
  }

  GetLeaveType = async () => {
    // this.self.setState({ isloading: true })
    // console.log("Leave",EmpId,AuthToken)
    const EmpId = await AsyncStorage.getItem('EmpId');
    const jsonValueClientID = await AsyncStorage.getItem('ClientId');
    const AuthToken = await AsyncStorage.getItem('AuthToken');

    console.log('LeaveApprovall');

    await axios
      .post(
        Endpoint.baseUrl + Endpoint.GetLeaveType,
        {
          EmpId: EmpId,
          ClientId: JSON.parse(jsonValueClientID),
        },
        {
          headers: {
            token: AuthToken,
          },
        },
      )
      .then(async response => {
        console.log('get_data...vendor', response.data.Table);
        let tmpArr = response.data.Table.map(val => {
          return val.LeaveName;
        });
        this.self.setState({
          DropdownVendorList: tmpArr,
        });
      })
      .catch(function (error) {
        // alert("Please Enter Valid Credentials")
        alert(response.data.message);
        // console.warn("guggsgggdsy", error);
      });
  };
}
