import React, {Component} from 'react';
import {
  View,
  StyleSheet,
  Image,
  Text,
  StatusBar,
  TouchableOpacity,
  BackHandler,
  ToastAndroid,
  ImageBackground,
  Platform,
  Alert,
  ActivityIndicator,
} from 'react-native';
import {vh, vw, normalize} from '../../../Utils/dimentions';
import utils from '../../../Utils';
import {SafeAreaView} from 'react-native-safe-area-context';
import moment from 'moment';
import Icon from 'react-native-vector-icons/FontAwesome';

import {withMyHook} from '../../../Utils/Dark';

import Modal from 'react-native-modal';
// import RNLocation from 'react-native-location'
import AsyncStorage from '@react-native-async-storage/async-storage';

import ProfiledHelper from './helper';
// navigator.geolocation = require('@react-native-community/geolocation');
class profile extends Component {
  constructor(props) {
    super(props);
    if (Text.defaultProps == null) Text.defaultProps = {};
    Text.defaultProps.allowFontScaling = false; //<--------Set allowFontScaling false for Screen

    this.state = {
      Contact: false,
      Address: false,
      PaySlip: false,
      Departmentt: false,
      Mobile: '',
      Name: '',
      DateofBirth: '',
      Address1: '',
      Department: '',
      Email: '',
      EmployeeName: '',
      JobTittle: '',
      ManagerName: '',
      Maritalstatus: '',
    };

    this.helper = new ProfiledHelper(this);
  }

  async componentDidMount() {
    this.helper.UserData(), this.helper.UserPersonalData();
    let Name = await AsyncStorage.getItem('Name');
    let Department = await AsyncStorage.getItem('Department');

    this.setState({
      Name: Name,
      // Department: Department
    });
  }

  render() {
    console.warn(ClockIn_datetime, 'hhhhhhhhh');
    const {
      play,
      user_name,
      profileName,
      User_Type,
      address,
      IsClockIn,
      ClockIn_datetime,
    } = this.state;
    return (
      <ImageBackground
        source={utils.icons.backImage}
        style={{flex: 1, height: '100%', width: '100%'}}>
        <View
          style={{
            backgroundColor: '#fff',
            height: 'auto',
            width: vw(390),
            alignSelf: 'center',
            marginTop: 100,
            paddingBottom: 50,

            borderRadius: 20,
            backgroundColor: '#0055C3',
          }}>
          <Image
            source={utils.icons.Userprofile}
            style={{
              height: vh(120),
              width: vw(120),
              alignSelf: 'center',
              borderRadius: normalize(60),
              marginTop: -60,
            }}
          />
          <Text
            style={[
              utils.fontStyle.FontFamilymachoB,
              {
                color: '#fff',
                fontSize: normalize(26),
                fontWeight: 'bold',
                alignSelf: 'center',
              },
            ]}>
            {this.state.EmployeeName}
          </Text>
          <Text
            style={[
              utils.fontStyle.FontFamilymachoB,
              {color: '#fff', fontSize: normalize(16), alignSelf: 'center'},
            ]}>
            {this.state.JobTittle}
          </Text>
          {/* Reject: r
Locationp
Lock: req
Payslip:  */}
        </View>
        <View
          style={{
            height: 'auto',
            width: '80%',
            backgroundColor: '#fff',
            alignSelf: 'center',
            marginTop: -20,
            borderRadius: 10,
            marginBottom: -50,
          }}>
          <View
            style={{
              flexDirection: 'row',
              justifyContent: 'space-between',
              padding: 15,
            }}>
            <View style={{flexDirection: 'row'}}>
              <Image
                source={utils.icons.Contact}
                style={{alignSelf: 'center'}}
              />
              <Text
                style={{
                  alignSelf: 'center',
                  marginLeft: 10,
                  fontSize: 18,
                  fontWeight: 'bold',
                  color: '#000',
                }}>
                Personal Details
              </Text>
            </View>
            {this.state.Contact == false ? (
              <TouchableOpacity
                style={{
                  alignSelf: 'center',
                  padding: 10,
                }}
                onPress={() => {
                  this.setState({
                    Contact: true,
                    Address: false,
                    PaySlip: false,
                    Departmentt: false,
                  });
                }}>
                <Image
                  source={utils.icons.down}
                  style={{alignSelf: 'center', marginRight: 10}}
                />
              </TouchableOpacity>
            ) : (
              <TouchableOpacity
                style={{
                  alignSelf: 'center',
                  padding: 10,
                }}
                onPress={() => {
                  this.setState({Contact: false});
                }}>
                <Image
                  source={utils.icons.Vector}
                  style={{alignSelf: 'center', marginRight: 10}}
                />
              </TouchableOpacity>
            )}
          </View>
          {this.state.Contact == true ? (
            <View
              style={{
                borderTopWidth: 1,
                borderBottomWidth: 1,
                borderColor: 'lightgrey',
                marginTop: 5,
                marginBottom: 10,
                padding: 5,
                marginLeft: 5,
              }}>
              <View style={{flexDirection: 'row'}}>
                <Icon
                  name="mobile"
                  size={30}
                  color="#3C97FF"
                  style={{alignSelf: 'center', marginLeft: 4, width: '8%'}}
                />

                <Text
                  style={{alignSelf: 'center', marginLeft: 10, fontSize: 16}}>
                  {this.state.Mobile}
                </Text>
              </View>
              <View style={{flexDirection: 'row', marginTop: 6}}>
                <Icon
                  name="envelope-o"
                  size={20}
                  color="#3C97FF"
                  style={{alignSelf: 'center', width: '8%'}}
                />
                <Text
                  style={{alignSelf: 'center', marginLeft: 10, fontSize: 16}}>
                  {this.state.Email}
                </Text>
              </View>
              <View style={{flexDirection: 'row', marginTop: 6}}>
                <Icon
                  name="gittip"
                  size={20}
                  color="#3C97FF"
                  style={{alignSelf: 'center', width: '8%'}}
                />
                <Text
                  style={{alignSelf: 'center', marginLeft: 10, fontSize: 16}}>
                  {this.state.Maritalstatus}
                </Text>
              </View>

              <View style={{flexDirection: 'row', marginTop: 6}}>
                <Icon
                  name="calendar-o"
                  size={20}
                  color="#3C97FF"
                  style={{alignSelf: 'center', width: '8%'}}
                />
                <Text
                  style={{alignSelf: 'center', marginLeft: 10, fontSize: 16}}>
                  {moment(this.state.DateofBirth).format('ll')}
                </Text>
              </View>
            </View>
          ) : null}

          <View
            style={{
              flexDirection: 'row',
              justifyContent: 'space-between',
              padding: 15,
            }}>
            <View style={{flexDirection: 'row'}}>
              <Image
                source={utils.icons.Locationp}
                style={{alignSelf: 'center'}}
              />
              <Text
                style={{
                  alignSelf: 'center',
                  marginLeft: 10,
                  fontSize: 18,
                  fontWeight: 'bold',
                  color: '#000',
                }}>
                Address
              </Text>
            </View>
            {this.state.Address == false ? (
              <TouchableOpacity
                style={{alignSelf: 'center', padding: 10}}
                onPress={() => {
                  this.setState({
                    Address: true,
                    Contact: false,
                    PaySlip: false,
                    Departmentt: false,
                  });
                }}>
                <Image
                  source={utils.icons.down}
                  style={{alignSelf: 'center', marginRight: 10}}
                />
              </TouchableOpacity>
            ) : (
              <TouchableOpacity
                style={{alignSelf: 'center', padding: 10}}
                onPress={() => {
                  this.setState({Address: false});
                }}>
                <Image
                  source={utils.icons.Vector}
                  style={{alignSelf: 'center', marginRight: 10}}
                />
              </TouchableOpacity>
            )}
          </View>
          {this.state.Address == true ? (
            <View
              style={{
                borderTopWidth: 1,
                borderBottomWidth: 1,
                borderColor: 'lightgrey',
                marginTop: 10,
                marginBottom: 10,
                padding: 5,
              }}>
              <View style={{flexDirection: 'row'}}>
                <Image
                  source={utils.icons.map}
                  style={{
                    height: vh(20),
                    width: vw(20),
                    alignSelf: 'center',
                    marginLeft: 5,
                  }}
                />
                <Text
                  style={{
                    alignSelf: 'center',
                    marginLeft: 10,
                    fontSize: 16,
                    width: 230,
                  }}>
                  {this.state.Address1}
                </Text>
              </View>
            </View>
          ) : null}

          <View
            style={{
              flexDirection: 'row',
              justifyContent: 'space-between',
              padding: 15,
            }}>
            <View style={{flexDirection: 'row'}}>
              <Image
                source={utils.icons.Payslip}
                style={{alignSelf: 'center'}}
              />
              <Text
                style={{
                  alignSelf: 'center',
                  marginLeft: 10,
                  fontSize: 18,
                  fontWeight: 'bold',
                  color: '#000',
                }}>
                Department
              </Text>
            </View>
            {this.state.Departmentt == false ? (
              <TouchableOpacity
                style={{alignSelf: 'center', padding: 10}}
                onPress={() => {
                  this.setState({
                    Departmentt: true,
                    Contact: false,
                    Address: false,
                  });
                }}>
                <Image
                  source={utils.icons.down}
                  style={{alignSelf: 'center', marginRight: 10}}
                />
              </TouchableOpacity>
            ) : (
              <TouchableOpacity
                style={{alignSelf: 'center', padding: 10}}
                onPress={() => {
                  this.setState({Departmentt: false});
                }}>
                <Image
                  source={utils.icons.Vector}
                  style={{alignSelf: 'center', marginRight: 10}}
                />
              </TouchableOpacity>
            )}
          </View>
          {this.state.Departmentt == true ? (
            <View
              style={{
                borderTopWidth: 1,
                borderBottomWidth: 1,
                borderColor: 'lightgrey',
                marginTop: 10,
                marginBottom: 10,
                padding: 5,
              }}>
              <View style={{flexDirection: 'row'}}>
                <Icon
                  name="user-circle"
                  size={20}
                  color="#3C97FF"
                  style={{alignSelf: 'center', width: '8%'}}
                />
                <Text
                  style={{
                    alignSelf: 'center',
                    marginLeft: 10,
                    fontSize: 16,
                    textAlign: 'center',
                  }}>
                  {this.state.ManagerName}
                </Text>
              </View>
              <View style={{flexDirection: 'row'}}>
                <Icon
                  name="vcard"
                  size={20}
                  color="#3C97FF"
                  style={{alignSelf: 'center', width: '8%'}}
                />
                <Text
                  style={{
                    alignSelf: 'center',
                    marginLeft: 10,
                    fontSize: 16,
                    textAlign: 'center',
                  }}>
                  {this.state.Department}
                </Text>
              </View>
            </View>
          ) : null}

          <View
            style={{
              flexDirection: 'row',
              justifyContent: 'space-between',
              padding: 15,
            }}>
            <View style={{flexDirection: 'row'}}>
              <Image
                source={utils.icons.Payslip}
                style={{alignSelf: 'center'}}
              />
              <Text
                style={{
                  alignSelf: 'center',
                  marginLeft: 10,
                  fontSize: 18,
                  fontWeight: 'bold',
                  color: '#000',
                }}>
                PaySlip
              </Text>
            </View>
            {this.state.PaySlip == false ? (
              <TouchableOpacity
                style={{alignSelf: 'center', padding: 10}}
                onPress={() => {
                  this.setState({
                    PaySlip: true,
                    Contact: false,
                    Address: false,
                    Departmentt: false,
                  });
                }}>
                <Image
                  source={utils.icons.down}
                  style={{alignSelf: 'center', marginRight: 10}}
                />
              </TouchableOpacity>
            ) : (
              <TouchableOpacity
                style={{alignSelf: 'center', padding: 10}}
                onPress={() => {
                  this.setState({PaySlip: false});
                }}>
                <Image
                  source={utils.icons.Vector}
                  style={{alignSelf: 'center', marginRight: 10}}
                />
              </TouchableOpacity>
            )}
          </View>
          {this.state.PaySlip == true ? (
            <View
              style={{
                borderTopWidth: 1,
                borderBottomWidth: 1,
                borderColor: 'lightgrey',
                flexDirection: 'row',
                marginTop: 10,
                marginBottom: 10,
                padding: 5,
              }}>
              {/* <Image
                                    source={utils.icons.phone}
                                    style={{ height: vh(20), width: vw(20), alignSelf: 'center', marginLeft: 5 }}
                                /> */}
              <Text
                style={{
                  alignSelf: 'center',
                  marginLeft: 10,
                  fontSize: 18,
                  textAlign: 'center',
                }}>
                Comming Soon
              </Text>
            </View>
          ) : null}
        </View>
        <View></View>
        <TouchableOpacity
          onPress={() => {
            this.setState({Logout: true});
            // this.props.navigation.navigate("Login"), AsyncStorage.setItem('IsAuthenticated', "false")}
          }}
          style={{
            height: 60,
            width: '80%',
            padding: 15,
            flexDirection: 'row',
            justifyContent: 'space-between',
            alignSelf: 'center',
            borderRadius: 20,
            marginTop: 80,
            backgroundColor: '#fff',
          }}>
          <View style={{flexDirection: 'row'}}>
            <Image source={utils.icons.Lock} style={{alignSelf: 'center'}} />
            <Text
              style={{
                alignSelf: 'center',
                fontSize: 20,
                fontWeight: 'bold',
                color: '#000',
                marginLeft: 15,
              }}>
              LogOut
            </Text>
          </View>
          <Image
            source={utils.icons.down}
            style={{alignSelf: 'center', marginRight: 10}}
          />
        </TouchableOpacity>
        <Modal isVisible={this.state.Logout}>
          <View
            style={{
              height: 'auto',
              width: '100%',
              backgroundColor: '#fff',
              borderRadius: 30,
            }}>
            <View
              style={{
                height: 100,
                width: 100,
                borderRadius: 100,
                backgroundColor: '#fff',
                marginTop: -50,
                alignSelf: 'center',
              }}>
              <Image
                source={utils.icons.Groupllot}
                style={{alignSelf: 'center', marginTop: 20}}
              />
            </View>
            <View style={{margin: 15}}>
              <Text
                style={[
                  utils.fontStyle.FontFamilyExtraBold,
                  {
                    textAlign: 'center',
                    color: '#000',
                    marginBottom: 10,
                    fontSize: 32,
                  },
                ]}>
                Are you sure want to logout?
              </Text>

              <TouchableOpacity
                onPress={() => {
                  AsyncStorage.setItem('IsAuthenticated', 'false'),
                    setTimeout(() => {
                      this.props.navigation.navigate('Login'),
                        this.setState({Logout: false});
                    }, 500);
                }}
                style={[styles.ButtonView, {marginTop: 20}]}>
                <ImageBackground
                  imageStyle={{borderRadius: 5}}
                  style={{
                    height: 37,
                    width: '100%',
                    justifyContent: 'center',
                    marginBottom: 20,
                  }}
                  source={utils.icons.buttonn}>
                  <Text
                    style={[
                      utils.fontStyle.TextSemiBold,
                      {color: '#fff'},
                      {textAlign: 'center', fontSize: 20},
                    ]}>
                    LogOut
                  </Text>
                </ImageBackground>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={() => {
                  this.setState({Logout: false});
                }}
                style={[styles.ButtonView, {marginTop: 10}]}>
                <ImageBackground
                  imageStyle={{tintColor: '#A3A3A3', borderRadius: 5}}
                  style={{
                    height: 37,
                    width: '100%',
                    justifyContent: 'center',
                    marginBottom: 20,
                  }}
                  source={utils.icons.buttonn}>
                  <Text
                    style={[
                      utils.fontStyle.TextSemiBold,
                      {color: '#fff'},
                      {textAlign: 'center', fontSize: 20},
                    ]}>
                    Cancel
                  </Text>
                </ImageBackground>
              </TouchableOpacity>
            </View>
          </View>
        </Modal>
      </ImageBackground>
    );
  }
}
export const Profile = withMyHook(profile);
const styles = StyleSheet.create({});
