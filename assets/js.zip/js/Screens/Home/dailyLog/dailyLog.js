import React, { Component } from 'react';
import { View,Text,StatusBar,ActivityIndicator,StyleSheet } from 'react-native';
import { WebView } from 'react-native-webview'
import utils from '../../../Utils';
import { Header } from "../../../Components/Header"
import { withMyHook } from "../../../Utils/Dark"
import { Calendar, CalendarList, Agenda, LocaleConfig } from 'react-native-calendars';

import { SafeAreaView } from 'react-native-safe-area-context';
const ActivityIndicatorElement = () => {
  return (
    <ActivityIndicator
      color="#009688"
      size="large"
      style={styles.activityIndicatorStyle}
    />
  );
};
class dailylog extends Component {
  
  render() {
    return (
        <SafeAreaView style={{ flex: 1,}}>
        <View style={{ flex: 1, backgroundColor: '#cccccc5c', }}>
            {/* <StatusBar
                hidden={false}
                backgroundColor={utils.color.HeaderColor}
            /> */}
            <Header
                title="Daily  Logs"
                lefticon={utils.icons.Back} leftFunction={() => { this.props.navigation.goBack() }}
            // rightIcon={utils.icons.splashLogo} rightFunctionality={() => { this.props.navigation.navigate("Profile") }}
            />

<View style={{ marginTop: 30,backgroundColor:'#fff',margin:20,borderRadius:30,padding:10 }}>
                                <Calendar
                                
                                    markingType={'period'}
                                    theme={{
                                        header: { height: 0 },
                                        backgroundColor: '#00adf5',
                                        calendarBackground: this.props.themeColor.DarkBackground,
                                        textSectionTitleColor: '#b6c1cd',
                                        textSectionTitleDisabledColor: '#d9e1e8',
                                        selectedDayBackgroundColor: 'red',
                                        selectedDayBackgroundColor: '#00adf5',
                                        // selectedDayTextColor: 'blue',
                                        todayTextColor: '#00adf5',
                                        dayTextColor: '#2d4150',
                                        textDisabledColor: 'grey',
                                        dotColor: '#00adf5',
                                        // selectedDotColor: 'red',
                                        arrowColor: utils.color.ButtonAll,
                                        disabledArrowColor: '#d9e1e8',
                                        monthTextColor: '#00adf5',
                                        indicatorColor: 'blue',
                                        textColor: this.props.themeColor.blackTitle,
                                        // textDayStyle:{color:this.props.themeColor.blackTitle},
                                        textDayFontWeight: '300',
                                        textMonthFontWeight: '300',
                                        textDayHeaderFontWeight: 'bold',
                                        textDayFontSize: 16,
                                        textMonthFontSize: 20,
                                        textDayHeaderFontSize: 16
                                    }}
                                    maxDate={'2099-09-22'}

                                    onDayPress={day => {
                                        console.log('selected day', day);
                                        console.log("nnnnnnnnn", this, this.helper)
                                        this.helper.FilterTask()
                                        this.setState({
                                            selectedDate: day
                                        })
                                    }}
                                    onDayLongPress={day => {
                                        console.log('selected day', day);
                                    }}

                                    monthFormat={'MMM yyyy'}

                                    // markingType='custom'
                                    onMonthChange={month => {
                                        console.log('month changed', month);
                                    }}


                                />

                        


                            </View>




                            <View style={{}}>

                            </View>
                  
      
      </View>
      </SafeAreaView>
    );
  }
}
export const DailyLogs = withMyHook(dailylog)
const styles = StyleSheet.create({
  container: {
    backgroundColor: '#F5FCFF',
    flex: 1,
  },
  activityIndicatorStyle: {
    flex: 1,
    justifyContent: 'center',
  },
});
