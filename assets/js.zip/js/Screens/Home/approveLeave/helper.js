import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';
import Endpoint from '../../../Utils/Endpoint';
import moment from 'moment';

export default class ApproveLeaveHelper {
  constructor(self) {
    this.self = self;
  }

  LeaveApprove = async () => {
    // this.self.setState({ isloading: true })
    // console.log("Leave",EmpId,AuthToken)
    const EmpId = await AsyncStorage.getItem('EmpId');
    const jsonValueClientID = await AsyncStorage.getItem('ClientId');
    const AuthToken = await AsyncStorage.getItem('AuthToken');
    const jsonValueUserType = await AsyncStorage.getItem('UserType');

    console.log('LeaveApprovall');

    await axios
      .post(
        Endpoint.baseUrl + Endpoint.LeaveApproval,
        {
          EmpId: EmpId,
          ClientId: JSON.parse(jsonValueClientID),
          Usertype: JSON.parse(jsonValueUserType),
        },
        {
          headers: {
            token: AuthToken,
            ClientId: JSON.parse(jsonValueClientID),
          },
        },
      )
      .then(async response => {
        console.log('gdfgdfhdfhdf', response.data);
        this.self.setState({
          LeaveRecord: response.data.Table,
        });
      })
      .catch(function (error) {
        // alert("Please Enter Valid Credentials")
        alert(response.data.message);
        // console.warn("guggsgggdsy", error);
      });
  };
  AddComments = async TransId => {
    // this.self.setState({ isloading: true })
    // alert(TransId);
    // alert('hhh');
    const EmpId = await AsyncStorage.getItem('EmpId');
    const jsonValueClientID = await AsyncStorage.getItem('ClientId');
    const AuthToken = await AsyncStorage.getItem('AuthToken');
    const jsonValueUserType = await AsyncStorage.getItem('UserType');
    console.log('Apppprovved', EmpId, jsonValueClientID, AuthToken, TransId);
    await axios
      .post(
        Endpoint.baseUrl + Endpoint.statusLeave,
        {
          EmpId: EmpId,
          Status: 'Approved',
          TransId: TransId,
          Comments: 'Ap By Mayank shukla',
          ClientId: JSON.parse(jsonValueClientID),
        },
        {
          headers: {
            token: AuthToken,
            ClientId: JSON.parse(jsonValueClientID),
          },
        },
      )
      // console.log("Leave",EmpId,AuthToken,TransId)

      .then(async response => {
        console.log(
          'dataapproved',
          EmpId,
          jsonValueClientID,
          AuthToken,
          TransId,
          Comments,
        );

        console.log('leave startsu', response.data);
      })
      .catch(function (error) {
        // alert('worng data');
      });
  };
  AddCommentsReject = async TransId => {
    const EmpId = await AsyncStorage.getItem('EmpId');
    const jsonValueClientID = await AsyncStorage.getItem('ClientId');
    const AuthToken = await AsyncStorage.getItem('AuthToken');
    const jsonValueUserType = await AsyncStorage.getItem('UserType');
    console.log('rejectedd', EmpId, jsonValueClientID, AuthToken, TransId);
    await axios
      .post(
        Endpoint.baseUrl + Endpoint.statusLeave,
        {
          EmpId: EmpId,
          Status: 'Rejected',
          TransId: TransId,
          Comments: 'R By Mayank shukla',
          ClientId: JSON.parse(jsonValueClientID),
        },
        {
          headers: {
            token: AuthToken,
            ClientId: JSON.parse(jsonValueClientID),
          },
        },
      )

      .then(async response => {
        console.log(
          'LeaveApprovall',
          EmpId,
          jsonValueClientID,
          AuthToken,
          TransId,
          Comments,
        );

        console.log(
          'hhghghghghghgh',
          EmpId,
          TransId,
          ClientId,
          Status,
          Comments,
        );
      })
      .catch(function (error) {
        // alert(response.data.message)
      });
  };
}
