import React, { Component } from 'react';
import { View, Text, StatusBar, Dimensions, StyleSheet } from 'react-native';
import { WebView } from 'react-native-webview'
import utils from '../../../Utils';
import { Header } from "../../../Components/Header"
import { withMyHook } from "../../../Utils/Dark"
import MapView, { PROVIDER_GOOGLE } from 'react-native-maps'; // remove PROVIDER_GOOGLE import if not using Google Maps

import { SafeAreaView } from 'react-native-safe-area-context';
const { width, height } = Dimensions.get('window');
const SCREEN_WIDTH = width;
const ASPECT_RATIO = width / height;
const LATITUDE = 28.345678;
const LONGITUDE = 77.345677;
const LATITUDE_DELTA = 0.0922;
const LONGITUDE_DELTA = LATITUDE_DELTA * ASPECT_RATIO;
class team extends Component {
  constructor(props) {
    super(props)
    this.state = {
      region: {
        latitude: LATITUDE,
        longitude: LONGITUDE,
        latitudeDelta: LATITUDE_DELTA,
        longitudeDelta: LONGITUDE_DELTA,
      },
    }
  }
  render() {
    return (
      <SafeAreaView style={{ flex: 1, backgroundColor: utils.color.HeaderColor }}>
        <View style={{ flex: 1, backgroundColor: '#fff', }}>
          {/* <StatusBar
                hidden={false}
                backgroundColor={utils.color.HeaderColor}
            /> */}
          <Header
            title="Team Tracler"
            lefticon={utils.icons.Back} leftFunction={() => { this.props.navigation.goBack() }}
          // rightIcon={utils.icons.splashLogo} rightFunctionality={() => { this.props.navigation.navigate("Profile") }}
          />







          <View style={{}}>
            <MapView
              provider={PROVIDER_GOOGLE} // remove if not using Google Maps
              scrollEnabled={true}
              // zoomEnabled={true}
              pitchEnabled={true}
              rotateEnabled={true}
              showsUserLocation={true}
              followsUserLocation={true}
              showsCompass={true}
              showsBuildings={true}
              showsTraffic={true}
              showsIndoors={true}
              style={{ height: '100%', width: '100%' }}
              region={{
                latitude: 37.78825,
                longitude: -122.4324,
                latitudeDelta: 0.015,
                longitudeDelta: 0.0121,
              }}
            >
            </MapView>
          </View>


        </View>
      </SafeAreaView>
    );
  }
}
export const Team = withMyHook(team)
const styles = StyleSheet.create({

});
