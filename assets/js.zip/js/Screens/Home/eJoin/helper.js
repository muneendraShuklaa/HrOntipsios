import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';
import Endpoint from '../../../Utils/Endpoint';
import moment from 'moment';

export default class EjoinHelper {
  constructor(self) {
    this.self = self;
  }
  EjoinBalance = async () => {
    // this.self.setState({ isloading: true })
    // console.log("Leave",EmpId,AuthToken)
    const EmpId = await AsyncStorage.getItem('EmpId');
    const jsonValueClientID = await AsyncStorage.getItem('ClientId');
    // const AuthToken = await AsyncStorage.getItem('AuthToken')
    // console.log("Leave",EmpId,AuthToken,JSON.parse(jsonValueClientID))

    await axios
      .post(
        Endpoint.baseUrl + Endpoint.EjoinData,
        {
          EmpId: 'JHT020',
          ClientId: JSON.parse(jsonValueClientID),
        },
        //     {
        //         headers:  {
        //         "token":AuthToken,

        //     },
        // }
      )
      .then(async response => {
        console.log('balance', response.data);
        this.self.setState({
          data: response.data.Table,
          // TaskName:response.data.Table[0].TaskName,
          // EmployeeUpload:response.data.Table[0].EmployeeUpload,
          // ViewDocument:response.data.Table[0].ViewDocument,
          // eSign:response.data.Table[0].eSign,
          // TaskName:response.data.Table[0].DocumentName,
        });
      })
      .catch(function (error) {
        // alert("Please Enter Valid Credentials")
        // alert(response.data.message);
        // console.warn("guggsgggdsy", error);
      });
  };

  DocUploadDownload = async taskData => {
    // this.self.setState({ isloading: true })
    // console.log("Leave",EmpId,AuthToken)
    const EmpId = await AsyncStorage.getItem('EmpId');
    const jsonValueClientID = await AsyncStorage.getItem('ClientId');
    // const AuthToken = await AsyncStorage.getItem('AuthToken')
    // console.log("Leave",EmpId,AuthToken,JSON.parse(jsonValueClientID))

    await axios
      .post(
        Endpoint.baseUrl + Endpoint.DocList,
        {
          EmpId: 'JHT020',
          Taskid: taskData.TaskId,
          ClientId: JSON.parse(jsonValueClientID),
        },
        //     {
        //         headers:  {
        //         "token":AuthToken,

        //     },
        // }
      )
      .then(async response => {
        this.self.setState({
          Docdata: response.data,
        });
      })
      .catch(function (error) {
        // alert("Please Enter Valid Credentials")
        alert(response.data.message);
        // console.warn("guggsgggdsy", error);
      });
  };
  uploadSingleDoc = async (img, DoCType) => {
    const jsonValue = await AsyncStorage.getItem('UserId');
    // alert("imagagagagagaeee")
    const jsonValueClientID = await AsyncStorage.getItem('ClientId');
    const EmpId = await AsyncStorage.getItem('EmpId');

    let data = new FormData();
    const extension = img.split('.').pop();
    data.append('EmpId', EmpId);
    data.append('ClientId', JSON.parse(jsonValueClientID));
    data.append('Taskid', JSON.parse(jsonValue));
    data.append('Docid', this.self.state.DoCType);
    data.append('document', {
      uri: img,
      name: 'image.' + extension,
      type: 'image/' + extension,
    });
    return fetch(Endpoint.baseUrl + Endpoint.EjoinData, {
      method: 'post',
      // headers: {
      //     // 'Content-Type': 'multipart/form-data',
      //     "Authorization" :Token
      // },
      body: data,
    }).then(response => response.json());
  };

  SingUpload = async (taskData, img) => {
    const jsonValue = await AsyncStorage.getItem('UserId');
    const jsonValueClientID = await AsyncStorage.getItem('ClientId');
    const EmpId = await AsyncStorage.getItem('EmpId');

    let data = new FormData();
    data.append('EmpId', EmpId);
    data.append('ClientId', jsonValueClientID);
    data.append('Taskid', taskData.TaskId);
    data.append('Docid', '0');
    data.append('document', {
      uri: img,
      name: 'image.png',
      type: 'image/png',
    });
    return fetch(Endpoint.baseUrl + Endpoint.EjoinData, {
      method: 'post',
      // headers: {
      //     // 'Content-Type': 'multipart/form-data',
      // "Authorization" :Token
      // },
      body: data,
    }).then(response => response.json());
  };
}
