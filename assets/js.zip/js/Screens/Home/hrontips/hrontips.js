import React, {Component} from 'react';
import {
  Text,
  View,
  StyleSheet,
  StatusBar,
  TouchableOpacity,
  Alert,
  TouchableHighlight,
  Image,
  ImageBackground,
  ScrollView,
} from 'react-native';
import {withMyHook} from '../../../Utils/Dark';
import {vh, vw, normalize} from '../../../Utils/dimentions';
import Modal from 'react-native-modal';
import {Header} from '../../../Components/Header';
// import { Timer, FlipNumber } from 'react-native-flip-timer';
import ImagePicker from 'react-native-image-crop-picker';
import {Stopwatch, Timer} from 'react-native-stopwatch-timer';
import LinearGradient from 'react-native-linear-gradient';
import AsyncStorage from '@react-native-async-storage/async-storage';
import utils from '../../../Utils';
import RNLocation from 'react-native-location';
import Geocoder from 'react-native-geocoder';
import DashboardHelper from './helper';
const timer = require('react-native-timer');
// const handleTimerComplete = () => alert("custom completion function");

const options = {
  container: {
    backgroundColor: utils.color.HeaderColor,
    padding: 5,
    borderRadius: 5,
    width: 220,
  },
  text: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#FFF',
    marginLeft: 7,
  },
};
class hrontips extends Component {
  constructor(props) {
    super(props);
    this.state = {
      sideModalD: false,
      play: false,
      ImagePicUrl: [],
      startTimeinSec: 0,
      imageArray2: [],
      imageselect: false,
      showMsg: false,
      timerStart: false,
      stopwatchStart: false,
      totalDuration: 90000,
      timerReset: false,
      stopwatchReset: false,
      isModalVisible: false,
      Name: '',
      address: '',
      latitude: '',
      longitude: '',
      Department: '',
    };
    this.toggleTimer = this.toggleTimer.bind(this);
    this.resetTimer = this.resetTimer.bind(this);
    this.toggleStopwatch = this.toggleStopwatch.bind(this);
    this.resetStopwatch = this.resetStopwatch.bind(this);
    this.helper = new DashboardHelper(this);
  }
  async componentDidMount() {
    this.helper.GetImageProfile();
    this.helper.UserData();
    timer.clearTimeout(this);
    let Name = await AsyncStorage.getItem('Name');
    let Department = await AsyncStorage.getItem('Department');

    this.getLocationUser();
    this.setState({
      Name: Name,
      Department: Department,
    });
  }
  toggleTimer() {
    this.setState({timerStart: !this.state.timerStart, timerReset: false});
  }

  resetTimer() {
    this.setState({timerStart: false, timerReset: true});
  }

  toggleStopwatch() {
    this.setState({stopwatchStart: true, stopwatchReset: false});
  }
  //   toggleStopwatch() {
  //     this.setState({stopwatchStart: !this.state.stopwatchStart, stopwatchReset: false});
  //   }

  resetStopwatch() {
    this.setState({stopwatchStart: false, stopwatchReset: true});
  }

  getFormattedTime(time) {
    this.currentTime = time;
  }

  showMsg() {
    this.setState({showMsg: true}, () =>
      timer.setTimeout(
        this,
        'hideMsg',
        () => this.setState({showMsg: false}),
        2000,
      ),
    );
  }
  clockout_Alert() {
    Alert.alert('Are you sure!', 'You want to Clock-Out', [
      {
        text: 'No',
        onPress: () => console.log('No'),
        style: 'Cancel',
      },
      {
        text: 'Yes',
        // onPress: () => this.props.navigation.navigate("Login")
        onPress: () => {
          this.setState({play: false});
        },
      },
    ]);
  }
  play = () => {
    this.setState(({play}) => ({play: !play}));
  };
  img_ipdate() {
    // console.warn("done")
    // this.helper.SaveTaskImage()
    alert('Uploaded succesfully');
  }
  takeScreenshot = () => {
    ImagePicker.openPicker({
      width: vw(300),
      height: vh(400),
      // multiple: true,
      cropping: true,
      // includeBase64: true
    })
      .then(imageUrl => {
        let tmpArr = this.state.imageArray2;
        tmpArr.push(imageUrl.path);
        console.warn(imageUrl.path);
        this.setState({imageArray2: tmpArr});
        this.img_ipdate();
        // console.warn(this.state.imageArray.path)
      })
      .catch(e => {
        console.log(e);
        Alert.alert(e.message ? e.message : e);
      });
  };
  pickSingleWithCamera() {
    ImagePicker.openCamera({
      width: 300,
      height: 400,
      cropping: true,
      includeBase64: true,
    })
      .then(imageUrl => {
        // let tmpArr = this.state.imageArray2
        // tmpArr.push(imageUrl.path)
        // console.warn(imageUrl.path)
        this.setState({imageArray2: mageUrl.path});
        this.img_ipdate();
        // console.warn(this.state.imageArray.path)
      })
      .catch(e => {
        console.log(e);
        Alert.alert(e.message ? e.message : e);
      });
  }
  getLocationUser = async () => {
    RNLocation.configure({
      distanceFilter: 5.0,
    });

    RNLocation.requestPermission({
      ios: 'whenInUse',
      android: {
        detail: 'coarse',
      },
    }).then(granted => {
      if (granted) {
        RNLocation.getLatestLocation({timeout: 60000}).then(latestLocation => {
          var NY = {
            lat: latestLocation.latitude,
            lng: latestLocation.longitude,
          };
          Geocoder.geocodePosition(NY)
            .then(res => {
              this.setState({address: res[0].locality});
            })
            .catch(err => console.log(err));

          this.setState({
            latitude: latestLocation.latitude,
            longitude: latestLocation.longitude,
            current_latitude: latestLocation.latitude,
            current_longitude: latestLocation.longitude,
          });
        });
      }
    });
  };
  render() {
    const {
      play,
      user_name,
      profileName,
      User_Type,
      address,
      IsClockIn,
      ClockIn_datetime,
    } = this.state;
    return (
      <ImageBackground
        source={utils.icons.backImage}
        style={{flex: 1, height: '100%', width: '100%'}}>
        {/* <View style={{ flex: 1, backgroundColor: this.props.themeColor.theameColor, marginTop: 20, }}> */}
        <StatusBar
          hidden={false}
          backgroundColor={utils.color.HeaderColor}
          translucent
          barStyle="light-content"
        />
        <ScrollView showsVerticalScrollIndicator={false} style={{}}>
          {/* <Header
                        title="Dashboard"
                        // lefticon={utils.icons.Back} leftFunction={() => { this.setState({ sideModalD: true }) }}
                    // rightIcon={utils.icons.padlock} rightFunctionality={() => { this.props.navigation.navigate("Profile") }}
                    /> */}
          <View style={{}}>
            <View
              style={{
                marginTop: 70,
                height: 'auto',
                width: '90%',
                alignSelf: 'center',
                backgroundColor: '#fff',
                shadowColor: '#000',
                shadowOffset: {
                  width: 0,
                  height: 2,
                },
                shadowOpacity: 0.23,
                shadowRadius: 2.62,
                elevation: 4,
                borderTopEndRadius: 30,
                borderTopStartRadius: 30,
              }}>
              <View
                style={{height: 'auto', width: '100%', marginBottom: vh(10)}}>
                <View
                  style={{
                    flexDirection: 'row',
                    marginTop: vh(20),
                    paddingHorizontal: vw(20),
                  }}>
                  <View style={{width: vw(290)}}>
                    {/* <Text>{this.state.ImagePicUrl}</Text> */}
                    <Text
                      style={[
                        utils.fontStyle.FontFamilymachoB,
                        {
                          color: '#000',
                          fontSize: normalize(32),
                          fontWeight: 'bold',
                        },
                      ]}>
                      {this.state.Name}
                    </Text>
                    <Text
                      style={[
                        utils.fontStyle.FontFamilymachoB,
                        {color: '#afafaf', fontSize: normalize(16)},
                      ]}>
                      {this.state.Department}
                    </Text>
                  </View>
                  <View style={{flexDirection: 'column'}}>
                    <View
                      style={{
                        height: vh(80),
                        width: vw(80),
                        borderRadius: normalize(80),
                        justifyContent: 'center',
                        backgroundColor: '#fff',
                        marginRight: vw(20),
                        alignItems: 'center',
                      }}>
                      {/* <Text style={{ fontSize: normalize(40), color: "#009BE7", fontWeight: 'bold' }} >MS</Text> */}
                      <Image
                        source={utils.icons.Userprofile}
                        // source={{
                        //     uri: `data:image/jpg;base64,${this.state.ImagePicUrl}`}}
                        style={{
                          height: vh(70),
                          width: vw(70),
                          alignSelf: 'center',
                          borderRadius: normalize(60),
                        }}
                      />
                    </View>
                  </View>
                </View>
                <View style={{marginLeft: 20, marginTop: -10}}>
                  {this.state.play == true ? (
                    <View style={{flexDirection: 'row'}}>
                      <Image
                        source={utils.icons.Clock}
                        style={{
                          height: vh(30),
                          width: vw(30),
                          alignSelf: 'center',
                          marginRight: 10,
                        }}
                      />
                      <Stopwatch
                        laps
                        msecs
                        start={this.state.stopwatchStart}
                        reset={this.state.stopwatchReset}
                        options={options}
                        //   getTime={this.getFormattedTime}
                      />
                    </View>
                  ) : null}
                  {this.state.play == true ? (
                    <View style={{flexDirection: 'row', marginTop: 5}}>
                      <Image
                        source={utils.icons.Location}
                        style={{
                          height: vh(30),
                          width: vw(30),
                          alignSelf: 'center',
                          marginRight: 10,
                        }}
                      />
                      <Text
                        style={[
                          utils.fontStyle.FontFamilymachoB,
                          {color: '#3083EF', fontSize: normalize(20)},
                        ]}>
                        {address}
                      </Text>
                    </View>
                  ) : null}
                </View>

                {/* <TouchableHighlight onPress={this.toggleStopwatch}>
          <Text style={{fontSize: 30}}>{!this.state.stopwatchStart ? "Start" : "Stop"}</Text>
        </TouchableHighlight>
        <TouchableHighlight onPress={this.resetStopwatch}>
          <Text style={{fontSize: 30}}>Reset</Text>
        </TouchableHighlight> */}
                {/* <Timer totalDuration={this.state.totalDuration} msecs start={this.state.timerStart}
          reset={this.state.timerReset}
          options={options}
          handleFinish={handleTimerComplete}
        //   getTime={this.getFormattedTime} 
        />
        <TouchableHighlight onPress={this.toggleTimer}>
          <Text style={{fontSize: 30}}>{!this.state.timerStart ? "Start" : "Stop"}</Text>
        </TouchableHighlight>
        <TouchableHighlight onPress={this.resetTimer}>
          <Text style={{fontSize: 30}}>Reset</Text>
        </TouchableHighlight> */}
                {/* <View style={{ flexDirection: 'row', height: "auto", marginTop: vh(-10) }}>
                                        {this.state.play == false ?
                                            <View style={{ marginTop: vh(10), marginLeft: vw(110) }}>
                                                <TouchableOpacity style={{ height: vh(45), backgroundColor: '#fff', width: vw(140), borderWidth: normalize(3), borderColor: '#DDDDDD', borderRadius: 10, borderWidth: 2, flexDirection: 'row', justifyContent: 'center', marginTop: vh(15) }} onPress={() => { this.setState({ play: true }) }}>
                                                    <Text style={[utils.fontStyle.FontFamilymachoB, { alignSelf: 'center', color: '#000', fontSize: normalize(18), textAlign: 'center' }]}>
                                                        Clock In  </Text>
                                                    <Image source={utils.icons.biplus} style={{ alignSelf: 'center', height: vh(30), width: vw(30) }} />
                                                </TouchableOpacity>


                                            </View>
                                            :
                                            <View style={{ marginTop: vh(10) }}>
                                
                                                <TouchableOpacity style={{ backgroundColor: '#fff', height: vh(45), width: vw(140), borderWidth: 3, borderColor: '#DDDDDD', marginRight: vw(20), borderRadius: 10, borderWidth: 2, borderColor: '#fff', flexDirection: 'row', justifyContent: 'center', marginTop: vh(15) }} onPress={() => { this.clockout_Alert() }} >
                                                    <Text style={[utils.fontStyle.FontFamilymachoB, { alignSelf: 'center', color: '#000', fontSize: normalize(18), textAlign: 'center' }]}>
                                                        Clock-Out   </Text>
                                                    <Image source={utils.icons.plus} style={{ alignSelf: 'center' }} />
                                                </TouchableOpacity>

                                            </View>
                                        }
                                        <View style={{ height: vh(100), width: vw(200), marginTop: vh(10), flexDirection: 'column' }}>
                                            {this.state.play == true ?
                                                <Timer time={this.state.startTimeinSec} play={play} />
                                                : null}

                                        </View>
                                    </View> */}
                {/* <TouchableOpacity onPress={() => requestAnimationFrame(() => this.showMsg())}>
          <Text>Press Me</Text>
        </TouchableOpacity>

        {this.state.showMsg ? (
          <Text>Hello!!</Text>
        ) : (
          null
        )} */}
                <View
                  style={{
                    flexDirection: 'row',
                    justifyContent: 'space-between',
                    marginLeft: 20,
                    marginRight: 20,
                    marginBottom: 10,
                  }}>
                  {/* <LinearGradient start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} colors={['#3083EF', "#88b8f6"]}
                                                style={{ height: vh(45), width: "45%", borderRadius: 5, marginTop: 15, justifyContent: 'center' }}> */}

                  <TouchableOpacity
                    style={{marginTop: 15}}
                    onPress={() => {
                      this.helper.track();
                      this.setState({ClockButton: true});
                    }}>
                    {play == true ? (
                      <ImageBackground
                        imageStyle={{tintColor: '#cacaca'}}
                        source={utils.icons.Rectangl}
                        style={{
                          height: vh(40),
                          width: 150,
                          alignSelf: 'center',
                          justifyContent: 'center',
                          alignSelf: 'center',
                        }}>
                        <Text
                          style={[
                            utils.fontStyle.FontFamilymachoB,
                            {
                              color: '#000',
                              fontSize: normalize(18),
                              textAlign: 'center',
                            },
                          ]}>
                          Clock In{' '}
                        </Text>
                      </ImageBackground>
                    ) : (
                      <ImageBackground
                        source={utils.icons.Rectangl}
                        style={{
                          height: vh(40),
                          width: 150,
                          alignSelf: 'center',
                          justifyContent: 'center',
                          alignSelf: 'center',
                        }}>
                        <Text
                          style={[
                            utils.fontStyle.FontFamilymachoB,
                            {
                              color: '#fff',
                              fontSize: normalize(18),
                              textAlign: 'center',
                            },
                          ]}>
                          Clock In{' '}
                        </Text>
                      </ImageBackground>
                    )}
                    {/* <Image source={utils.icons.biplus} style={{ alignSelf: 'center', height: vh(30), width: vw(30) }} /> */}
                  </TouchableOpacity>

                  {/* </LinearGradient> */}
                  {/* <LinearGradient start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} colors={['#999999', "#cacaca"]}
                                                style={{ height: vh(45), width:"45%", borderRadius: 5, marginTop: 15, justifyContent: 'center' }}> */}
                  <TouchableOpacity
                    style={{marginTop: 15}}
                    onPress={() => {
                      this.resetStopwatch();
                      this.setState({play: false});
                    }}>
                    {play == true ? (
                      <ImageBackground
                        // imageStyle={{tintColor: '#cacaca'}}
                        source={utils.icons.Rectangl}
                        style={{
                          height: vh(40),
                          width: 150,
                          alignSelf: 'center',
                          justifyContent: 'center',
                          alignSelf: 'center',
                        }}>
                        <Text
                          style={[
                            utils.fontStyle.FontFamilymachoB,
                            {
                              alignSelf: 'center',
                              color: '#fff',
                              fontSize: normalize(18),
                              textAlign: 'center',
                            },
                          ]}>
                          Clock-Out{' '}
                        </Text>
                      </ImageBackground>
                    ) : (
                      <ImageBackground
                        imageStyle={{tintColor: '#cacaca'}}
                        source={utils.icons.Rectangl}
                        style={{
                          height: vh(40),
                          width: 150,
                          alignSelf: 'center',
                          justifyContent: 'center',
                          alignSelf: 'center',
                        }}>
                        <Text
                          style={[
                            utils.fontStyle.FontFamilymachoB,
                            {
                              alignSelf: 'center',
                              color: '#000',
                              fontSize: normalize(18),
                              textAlign: 'center',
                            },
                          ]}>
                          Clock-Out{' '}
                        </Text>
                      </ImageBackground>
                    )}
                    {/* <Image source={utils.icons.biplus} style={{ alignSelf: 'center', height: vh(30), width: vw(30) }} /> */}
                  </TouchableOpacity>

                  {/* </LinearGradient> */}
                </View>
              </View>
            </View>

            <View style={{paddingLeft: 20, paddingRight: 20}}>
              <Text
                style={[
                  utils.fontStyle.FontFamilyRegular,
                  {
                    marginTop: this.state.play == true ? 30 : 30,
                    color: this.props.themeColor.textColor,
                    fontSize: normalize(16),
                  },
                ]}>
                What's New
              </Text>
              <View
                style={{
                  flexDirection: 'row',
                  marginTop: 5,
                  justifyContent: 'space-between',
                  height: 50,
                  width: '100%',
                  borderRadius: 5,
                  alignSelf: 'center',
                  backgroundColor: '#fff',
                  shadowColor: '#000',
                  shadowOffset: {
                    width: 0,
                    height: 2,
                  },
                  shadowOpacity: 0.23,
                  shadowRadius: 2.62,
                  elevation: 4,
                }}>
                <View style={{flexDirection: 'row'}}>
                  <Image
                    source={utils.icons.Cake}
                    style={{
                      height: vh(30),
                      width: vw(30),
                      alignSelf: 'center',
                      marginLeft: 10,
                    }}
                  />
                  <Text
                    style={[
                      utils.fontStyle.FontFamilyRegular,
                      {
                        alignSelf: 'center',
                        marginLeft: 10,
                        color: this.props.themeColor.textColor,
                        fontSize: normalize(22),
                      },
                    ]}>
                    Happy Birthday Monika
                  </Text>
                </View>
                <View style={{alignSelf: 'center'}}>
                  <Image
                    source={utils.icons.Balloons}
                    style={{
                      height: vh(30),
                      width: vw(30),
                      alignSelf: 'center',
                      marginRight: 10,
                    }}
                  />
                </View>
              </View>
              <View
                style={{
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  marginTop: 30,
                }}>
                <TouchableOpacity
                  onPress={() => {
                    alert('We are launching soon..');
                  }}
                  style={[styles.Card, {}]}>
                  <Image
                    source={utils.icons.Primetime}
                    style={{alignSelf: 'center', height: 30, width: 30}}
                  />
                  <Text
                    style={[
                      utils.fontStyle.FontFamilyRegular,
                      {
                        alignSelf: 'center',
                        color: this.props.themeColor.textColor,
                        fontSize: normalize(18),
                        marginTop: 7,
                      },
                    ]}>
                    My Task
                  </Text>
                </TouchableOpacity>

                <TouchableOpacity
                  onPress={() => {
                    alert('We are launching soon..');
                  }}
                  style={[styles.Card, {}]}>
                  <Image
                    source={utils.icons.Menu}
                    style={{alignSelf: 'center', height: vh(30), width: vw(30)}}
                  />
                  <Text
                    style={[
                      utils.fontStyle.FontFamilyRegular,
                      {
                        alignSelf: 'center',
                        color: this.props.themeColor.textColor,
                        fontSize: normalize(18),
                        marginTop: 7,
                      },
                    ]}>
                    DSR
                  </Text>
                </TouchableOpacity>
              </View>

              <View
                style={{
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  marginTop: 30,
                }}>
                <TouchableOpacity
                  onPress={() => {
                    alert('We are launching soon..');
                  }}
                  style={[styles.Card, {}]}>
                  <Image
                    source={utils.icons.Clipboard}
                    style={{alignSelf: 'center', height: 30, width: 30}}
                  />
                  <Text
                    style={[
                      utils.fontStyle.FontFamilyRegular,
                      {
                        alignSelf: 'center',
                        color: this.props.themeColor.textColor,
                        fontSize: normalize(18),
                        marginTop: 7,
                      },
                    ]}>
                    Daily Logs
                  </Text>
                </TouchableOpacity>

                <TouchableOpacity
                  onPress={() => {
                    this.props.navigation.navigate('ApproveLeaves');
                  }}
                  style={[styles.Card]}>
                  <Image
                    source={utils.icons.Bills}
                    style={{alignSelf: 'center', height: 30, width: 30}}
                  />
                  <Text
                    style={[
                      utils.fontStyle.FontFamilyRegular,
                      {
                        alignSelf: 'center',
                        color: this.props.themeColor.textColor,
                        fontSize: normalize(18),
                        marginTop: 7,
                      },
                    ]}>
                    Approve Leave
                  </Text>
                </TouchableOpacity>
              </View>

              <View
                style={{
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  marginTop: 30,
                  marginBottom: 10,
                }}>
                <TouchableOpacity
                  onPress={() => {
                    this.props.navigation.navigate('LeaveBalance');
                  }}
                  style={[styles.Card, {}]}>
                  <Image
                    source={utils.icons.Research}
                    style={{alignSelf: 'center', height: 30, width: 30}}
                  />
                  <Text
                    style={[
                      utils.fontStyle.FontFamilyRegular,
                      {
                        alignSelf: 'center',
                        color: this.props.themeColor.textColor,
                        fontSize: normalize(18),
                        marginTop: 7,
                      },
                    ]}>
                    leave Status
                  </Text>
                </TouchableOpacity>

                <TouchableOpacity
                  onPress={() => {
                    this.props.navigation.navigate('RequestLeave');
                  }}
                  style={[styles.Card]}>
                  <Image
                    source={utils.icons.List}
                    style={{alignSelf: 'center', height: 30, width: 30}}
                  />
                  <Text
                    style={[
                      utils.fontStyle.FontFamilyRegular,
                      {
                        alignSelf: 'center',
                        textAlign: 'center',
                        color: this.props.themeColor.textColor,
                        fontSize: normalize(18),
                        marginTop: 7,
                      },
                    ]}>
                    Apply Leave
                  </Text>
                </TouchableOpacity>
              </View>
              {/* <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginTop: 20, marginBottom: 20 }}>

                                    <TouchableOpacity onPress={() => { this.props.navigation.navigate("LeaveBalance") }} style={[styles.Card,{ }]}>
                                        <Image source={utils.icons.List} style={{ alignSelf: 'center',height:30,width:30 }} />
                                        <Text style={[utils.fontStyle.FontFamilyRegular, { alignSelf: 'center', color: this.props.themeColor.textColor, fontSize: normalize(18),marginTop:7 }]}>
                                            Leave Balance</Text>
                                    </TouchableOpacity>


                                    <TouchableOpacity onPress={() => { this.props.navigation.navigate("leaveStatus") }} style={[styles.Card]}>
                                        <Image source={utils.icons.eye} style={{ alignSelf: 'center',height:50,width:50 }} />
                                        <Text style={[utils.fontStyle.FontFamilyRegular, { alignSelf: 'center', color: this.props.themeColor.textColor, fontSize: normalize(18),marginTop:7 }]}>
                                            Leave Status</Text>
                                    </TouchableOpacity>

                                </View> */}
            </View>
          </View>
        </ScrollView>

        <Modal
          isVisible={this.state.sideModalD}
          backdropColor="transparent"
          onBackdropPress={() => {
            this.setState({sideModalD: false});
          }}
          // onBackdropPress={() => sideModalD(false)}

          animationIn="slideInLeft"
          animationOut="slideOutLeft"
          style={{margin: 0, backgroundColor: 'transform'}}>
          <View
            style={{
              flex: 1,
              backgroundColor: utils.color.lightBackgroundGrey,
              marginLeft: vw(-10),
            }}>
            <StatusBar hidden={false} />
            <View
              style={{
                height: '100%',
                width: vw(340),
                backgroundColor: utils.color.ButtonAll,
                borderTopRightRadius: 30,
                borderBottomRightRadius: 30,
              }}>
              <View
                style={{
                  height: '100%',
                  width: '100%',
                  backgroundColor: utils.color.background,
                }}>
                <View style={{flex: 1}}>
                  {/* <TouchableOpacity

                                                onPress={() => this.setState({ sideModalD: false })}
                                                style={{ padding: 0, paddingBottom: 60 }}
                                            >
                                                <Image source={utils.icons.Back} style={{ alignSelf: 'flex-end', marginTop: vh(50), marginRight: vw(30), height: vh(40), width: vw(40), tintColor: '#fff' }} />
                                            </TouchableOpacity> */}
                  <View style={{backgroundColor: utils.color.HeaderColor}}>
                    {/* <TouchableOpacity  >
                                                    <Image source={utils.icons.User} style={{ alignSelf: 'center', height: vh(150), width: vw(150), }} />
                                                </TouchableOpacity> */}
                    <TouchableOpacity
                      onPress={() => {
                        this.setState({imageselect: true});
                      }}
                      style={{
                        height: vh(112),
                        alignSelf: 'center',
                        width: vw(112),
                        borderRadius: 110,
                        justifyContent: 'center',
                        backgroundColor: '#fff',
                        alignItems: 'center',
                        marginTop: 50,
                      }}>
                      {/* <Text style={{ fontSize: 36, color: utils.color.HeaderColor, fontWeight: 'bold' }} >{profileName}</Text> */}
                      <Image
                        source={utils.icons.Userprofile}
                        style={{
                          height: vh(105),
                          width: vw(100),
                          alignSelf: 'center',
                        }}
                      />
                    </TouchableOpacity>
                    <View
                      style={{
                        flexDirection: 'column',
                        alignSelf: 'center',
                        marginTop: vh(10),
                        marginBottom: vh(30),
                      }}>
                      <Text
                        style={[
                          utils.fontStyle.FontFamilymachoB,
                          {
                            alignSelf: 'center',
                            color: utils.color.whiteText,
                            fontSize: normalize(24),
                          },
                        ]}>
                        Hello Mariakaa{' '}
                      </Text>
                    </View>
                  </View>
                  <TouchableOpacity
                    onPress={() => {
                      this.setState({sideModalD: false});
                      this.props.navigation.navigate('Terms');
                    }}>
                    <View
                      style={{
                        marginLeft: vw(30),
                        marginTop: Platform.OS === 'ios' ? vh(20) : vh(10),
                        flexDirection: 'row',
                      }}>
                      <Image
                        style={{
                          height: vh(30),
                          width: vw(30),
                          tintColor: '#fff',
                          alignSelf: 'center',
                          marginRight: vw(20),
                        }}
                        source={utils.icons.AboutUs}></Image>

                      <Text
                        style={[
                          utils.fontStyle.FontFamilyBold,
                          {
                            fontSize: normalize(20),
                            color: utils.color.whiteText,
                          },
                        ]}>
                        My Profile
                      </Text>
                    </View>
                  </TouchableOpacity>
                  <TouchableOpacity
                    onPress={() => {
                      this.setState({sideModalD: false});
                      this.props.navigation.navigate('Goal');
                    }}>
                    <View
                      style={{
                        marginLeft: vw(30),
                        marginTop: Platform.OS === 'ios' ? vh(20) : vh(10),
                        flexDirection: 'row',
                      }}>
                      <Image
                        style={{
                          height: vh(30),
                          width: vw(30),
                          tintColor: '#fff',
                          alignSelf: 'center',
                          marginRight: vw(20),
                        }}
                        source={utils.icons.AboutUs}></Image>

                      <Text
                        style={[
                          utils.fontStyle.FontFamilyBold,
                          {
                            fontSize: normalize(20),
                            color: utils.color.whiteText,
                          },
                        ]}>
                        My goal
                      </Text>
                    </View>
                  </TouchableOpacity>
                  <TouchableOpacity
                    onPress={() => {
                      this.setState({sideModalD: false});
                      this.props.navigation.navigate('Terms');
                    }}>
                    <View
                      style={{
                        marginLeft: vw(30),
                        marginTop: Platform.OS === 'ios' ? vh(20) : vh(10),
                        flexDirection: 'row',
                      }}>
                      <Image
                        style={{
                          height: vh(30),
                          width: vw(30),
                          tintColor: '#fff',
                          alignSelf: 'center',
                          marginRight: vw(20),
                        }}
                        source={utils.icons.AboutUs}></Image>

                      <Text
                        style={[
                          utils.fontStyle.FontFamilyBold,
                          {
                            fontSize: normalize(20),
                            color: utils.color.whiteText,
                          },
                        ]}>
                        My task
                      </Text>
                    </View>
                  </TouchableOpacity>
                  <TouchableOpacity
                    onPress={() => {
                      this.setState({sideModalD: false});
                      this.props.navigation.navigate('Announcement');
                    }}>
                    <View
                      style={{
                        marginLeft: vw(30),
                        marginTop: Platform.OS === 'ios' ? vh(20) : vh(10),
                        flexDirection: 'row',
                      }}>
                      <Image
                        style={{
                          height: vh(30),
                          width: vw(30),
                          tintColor: '#fff',
                          alignSelf: 'center',
                          marginRight: vw(20),
                        }}
                        source={utils.icons.AboutUs}></Image>

                      <Text
                        style={[
                          utils.fontStyle.FontFamilyBold,
                          {
                            fontSize: normalize(20),
                            color: utils.color.whiteText,
                          },
                        ]}>
                        Announcement
                      </Text>
                    </View>
                  </TouchableOpacity>
                  <TouchableOpacity
                    onPress={() => {
                      this.setState({sideModalD: false});
                      this.props.navigation.navigate('DSR');
                    }}>
                    <View
                      style={{
                        marginLeft: vw(30),
                        marginTop: Platform.OS === 'ios' ? vh(20) : vh(10),
                        flexDirection: 'row',
                      }}>
                      <Image
                        style={{
                          height: vh(30),
                          width: vw(30),
                          tintColor: '#fff',
                          alignSelf: 'center',
                          marginRight: vw(20),
                        }}
                        source={utils.icons.AboutUs}></Image>

                      <Text
                        style={[
                          utils.fontStyle.FontFamilyBold,
                          {
                            fontSize: normalize(20),
                            color: utils.color.whiteText,
                          },
                        ]}>
                        DSR
                      </Text>
                    </View>
                  </TouchableOpacity>
                  <TouchableOpacity
                    onPress={() => {
                      this.setState({sideModalD: false});
                      this.props.navigation.navigate('Terms');
                    }}>
                    <View
                      style={{
                        marginLeft: vw(30),
                        marginTop: Platform.OS === 'ios' ? vh(20) : vh(10),
                        flexDirection: 'row',
                      }}>
                      <Image
                        style={{
                          height: vh(30),
                          width: vw(30),
                          tintColor: '#fff',
                          alignSelf: 'center',
                          marginRight: vw(20),
                        }}
                        source={utils.icons.AboutUs}></Image>

                      <Text
                        style={[
                          utils.fontStyle.FontFamilyBold,
                          {
                            fontSize: normalize(20),
                            color: utils.color.whiteText,
                          },
                        ]}>
                        My Team
                      </Text>
                    </View>
                  </TouchableOpacity>
                  <TouchableOpacity
                    onPress={() => {
                      this.setState({sideModalD: false});
                      this.props.navigation.navigate('Terms');
                    }}>
                    <View
                      style={{
                        marginLeft: vw(30),
                        marginTop: Platform.OS === 'ios' ? vh(20) : vh(10),
                        flexDirection: 'row',
                      }}>
                      <Image
                        style={{
                          height: vh(30),
                          width: vw(30),
                          tintColor: '#fff',
                          alignSelf: 'center',
                          marginRight: vw(20),
                        }}
                        source={utils.icons.AboutUs}></Image>

                      <Text
                        style={[
                          utils.fontStyle.FontFamilyBold,
                          {
                            fontSize: normalize(20),
                            color: utils.color.whiteText,
                          },
                        ]}>
                        Reimbursement
                      </Text>
                    </View>
                  </TouchableOpacity>
                  <TouchableOpacity
                    onPress={() => {
                      this.setState({sideModalD: false});
                      this.props.navigation.navigate('Terms');
                    }}>
                    <View
                      style={{
                        marginLeft: vw(30),
                        marginTop: Platform.OS === 'ios' ? vh(20) : vh(10),
                        flexDirection: 'row',
                      }}>
                      <Image
                        style={{
                          height: vh(30),
                          width: vw(30),
                          tintColor: '#fff',
                          alignSelf: 'center',
                          marginRight: vw(20),
                        }}
                        source={utils.icons.AboutUs}></Image>

                      <Text
                        style={[
                          utils.fontStyle.FontFamilyBold,
                          {
                            fontSize: normalize(20),
                            color: utils.color.whiteText,
                          },
                        ]}>
                        Regularization
                      </Text>
                    </View>
                  </TouchableOpacity>
                  <TouchableOpacity
                    onPress={() => {
                      this.setState({sideModalD: false});
                      this.props.navigation.navigate('Terms');
                    }}>
                    <View
                      style={{
                        marginLeft: vw(30),
                        marginTop: Platform.OS === 'ios' ? vh(20) : vh(10),
                        flexDirection: 'row',
                      }}>
                      <Image
                        style={{
                          height: vh(30),
                          width: vw(30),
                          tintColor: '#fff',
                          alignSelf: 'center',
                          marginRight: vw(20),
                        }}
                        source={utils.icons.AboutUs}></Image>

                      <Text
                        style={[
                          utils.fontStyle.FontFamilyBold,
                          {
                            fontSize: normalize(20),
                            color: utils.color.whiteText,
                          },
                        ]}>
                        Terms & Services
                      </Text>
                    </View>
                  </TouchableOpacity>
                  <TouchableOpacity
                    onPress={() => {
                      this.setState({sideModalD: false});
                      this.props.navigation.navigate('Terms');
                    }}>
                    <View
                      style={{
                        marginLeft: vw(30),
                        marginTop: Platform.OS === 'ios' ? vh(20) : vh(10),
                        flexDirection: 'row',
                      }}>
                      <Image
                        style={{
                          height: vh(30),
                          width: vw(30),
                          tintColor: '#fff',
                          alignSelf: 'center',
                          marginRight: vw(20),
                        }}
                        source={utils.icons.AboutUs}></Image>

                      <Text
                        style={[
                          utils.fontStyle.FontFamilyBold,
                          {
                            fontSize: normalize(20),
                            color: utils.color.whiteText,
                          },
                        ]}>
                        Manage Attendance
                      </Text>
                    </View>
                  </TouchableOpacity>

                  <TouchableOpacity
                    onPress={() => {
                      this.setState({sideModalD: false});
                      this.props.navigation.navigate('Terms');
                    }}>
                    <View
                      style={{
                        marginLeft: vw(30),
                        marginTop: Platform.OS === 'ios' ? vh(20) : vh(10),
                        flexDirection: 'row',
                      }}>
                      <Image
                        style={{
                          height: vh(30),
                          width: vw(30),
                          tintColor: '#fff',
                          alignSelf: 'center',
                          marginRight: vw(20),
                        }}
                        source={utils.icons.AboutUs}></Image>

                      <Text
                        style={[
                          utils.fontStyle.FontFamilyBold,
                          {
                            fontSize: normalize(20),
                            color: utils.color.whiteText,
                          },
                        ]}>
                        Reset Password
                      </Text>
                    </View>
                  </TouchableOpacity>
                  <TouchableOpacity
                    onPress={() => {
                      this.setState({sideModalD: false});
                      this.props.navigation.navigate('Privacy');
                    }}>
                    <View
                      style={{
                        marginLeft: vw(30),
                        flexDirection: 'row',
                        marginTop: Platform.OS === 'ios' ? vh(20) : vh(10),
                      }}>
                      <Image
                        style={{
                          height: vh(30),
                          width: vw(30),
                          tintColor: '#fff',
                          alignSelf: 'center',
                          marginRight: vw(20),
                        }}
                        source={utils.icons.Privacy}></Image>

                      <Text
                        style={[
                          utils.fontStyle.FontFamilyBold,
                          {
                            fontSize: normalize(20),
                            color: utils.color.whiteText,
                          },
                        ]}>
                        Privacy policy
                      </Text>
                    </View>
                  </TouchableOpacity>
                  <TouchableOpacity
                    onPress={() => {
                      this.setState({sideModalD: false});
                      this.props.navigation.navigate('AboutUs');
                    }}>
                    <View
                      style={{
                        marginLeft: vw(30),
                        flexDirection: 'row',
                        marginTop: Platform.OS === 'ios' ? vh(20) : vh(10),
                      }}>
                      <Image
                        style={{
                          height: vh(30),
                          width: vw(30),
                          tintColor: '#fff',
                          alignSelf: 'center',
                          marginRight: vw(20),
                        }}
                        source={utils.icons.AboutUs}></Image>

                      <Text
                        style={[
                          utils.fontStyle.FontFamilyBold,
                          {
                            fontSize: normalize(20),
                            color: utils.color.whiteText,
                          },
                        ]}>
                        About Us
                      </Text>
                    </View>
                  </TouchableOpacity>
                  <TouchableOpacity
                    onPress={() => {
                      this.setState({sideModalD: false});
                      this.Logout_Alert();
                    }}>
                    <View
                      style={{
                        marginLeft: vw(30),
                        flexDirection: 'row',
                        marginTop: Platform.OS === 'ios' ? vh(20) : vh(10),
                      }}>
                      <Image
                        style={{
                          height: vh(30),
                          width: vw(30),
                          tintColor: '#fff',
                          alignSelf: 'center',
                          marginRight: vw(20),
                        }}
                        source={utils.icons.Go}></Image>

                      <Text
                        style={[
                          utils.fontStyle.FontFamilyBold,
                          {
                            fontSize: normalize(20),
                            color: utils.color.whiteText,
                          },
                        ]}>
                        Log out
                      </Text>
                    </View>
                  </TouchableOpacity>
                </View>
              </View>
            </View>
          </View>
        </Modal>
        <Modal
          isVisible={this.state.imageselect}
          animationIn="zoomInDown"
          animationOut="bounceOutDown"
          style={{}}>
          <View
            style={{
              flex: 1,
              backgroundColor: utils.color.lightBackgroundGrey,
              justifyContent: 'flex-end',
            }}>
            <View
              style={{
                height: vh(200),
                width: '100%',
                borderWidth: 1,
                borderColor: this.props.themeColor.border,
                backgroundColor: '#fff',
                borderTopRightRadius: 30,
                borderTopLeftRadius: 30,
              }}>
              <Text
                style={[
                  utils.fontStyle.FontFamilyBold,
                  {
                    color: '#000',
                    marginTop: 10,
                    textAlign: 'center',
                    color: '#009BE7',
                  },
                ]}>
                Upload Task Image
              </Text>

              <View
                style={{
                  marginTop: 15,
                  flexDirection: 'row',
                  paddingLeft: 30,
                  paddingRight: 30,
                  justifyContent: 'space-between',
                }}>
                <TouchableOpacity
                  style={{flexDirection: 'column', marginTop: 15}}
                  onPress={() => {
                    this.pickSingleWithCamera(),
                      this.setState({imageselect: false});
                  }}>
                  <Image
                    source={utils.icons.Cameraa}
                    style={{alignSelf: 'center', height: vh(63), width: vw(60)}}
                  />
                  <Text
                    style={[
                      utils.fontStyle.FontFamilyBold,
                      {
                        color: this.props.themeColor.blackTitle,
                        marginBottom: 10,
                        alignSelf: 'center',
                      },
                    ]}>
                    Camera
                  </Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={{flexDirection: 'column', marginTop: 15}}
                  onPress={() => {
                    this.takeScreenshot(), this.setState({imageselect: false});
                  }}>
                  <Image
                    source={utils.icons.Imagee}
                    style={{alignSelf: 'center', height: vh(63), width: vw(60)}}
                  />
                  <Text
                    style={[
                      utils.fontStyle.FontFamilyBold,
                      {
                        color: this.props.themeColor.blackTitle,
                        marginBottom: 10,
                        alignSelf: 'center',
                      },
                    ]}>
                    Gallery
                  </Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={{flexDirection: 'column', marginTop: 15}}
                  onPress={() => {
                    this.setState({imageselect: false});
                  }}>
                  <Image
                    source={utils.icons.Cancel}
                    style={{
                      tintColor: 'lightgrey',
                      alignSelf: 'center',
                      height: vh(63),
                      width: vw(60),
                    }}
                  />
                  <Text
                    style={[
                      utils.fontStyle.FontFamilyBold,
                      {
                        color: this.props.themeColor.blackTitle,
                        marginBottom: 10,
                        alignSelf: 'center',
                      },
                    ]}>
                    Cancel
                  </Text>
                </TouchableOpacity>
              </View>
            </View>
          </View>
        </Modal>
        <Modal
          isVisible={this.state.isModalVisible}
          onBackdropPress={() => {
            this.setState({isModalVisible: false});
          }}
          // animationType="slide"
          // transparent={true}
          // visible={this.state.isModalVisible}
          style={{}}>
          <View
            style={{
              alignSelf: 'center',
              borderWidth: 5,
              borderColor: '#560BAD',
              height: 'auto',
              width: '100%',
              borderTopRightRadius: 80,
              borderTopLeftRadius: 80,
              backgroundColor: utils.color.whiteText,
            }}>
            {/* <L View style={{ height: 220, width: 220, alignSelf: 'center', marginBottom: 20, }} source={require('../../../Components/Lottie/98449-coming-soon.json')} autoPlay loop /> */}
            <Text
              style={{
                color: '#fff',
                alignSelf: 'center',
                textAlign: 'center',
                fontSize: 20,
                marginBottom: 30,
                marginTop: 40,
                fontWeight: 'bold',
              }}>
              We're currently working on It{'\n'} We'll Launching Soon...
            </Text>
            <TouchableOpacity
              onPress={() => {
                this.setState({isModalVisible: false});
              }}
              style={{
                backgroundColor: 'grey',
                height: vh(40),
                width: '100%',
                justifyContent: 'center',
              }}>
              <Text
                style={{
                  color: '#fff',
                  fontSize: normalize(20),
                  fontWeight: 'bold',
                  textAlign: 'center',
                }}>
                Back to Home
              </Text>
            </TouchableOpacity>
          </View>
        </Modal>

        {/* </View> */}
      </ImageBackground>
    );
  }
}
export const HrOnTips = withMyHook(hrontips);
var styles = StyleSheet.create({
  viewhome: {
    height: 100,
    borderRadius: 10,
    width: '47%',
    justifyContent: 'center',
  },
  Card: {
    height: 89,
    width: '47%',
    alignSelf: 'center',
    backgroundColor: '#fff',
    justifyContent: 'center',
    borderRadius: 10,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowOpacity: 0.23,
    shadowRadius: 2.62,
    elevation: 4,
  },
});
