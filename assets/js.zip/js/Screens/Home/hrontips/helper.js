import axios from 'axios'
import AsyncStorage from '@react-native-async-storage/async-storage';
import Endpoint from '../../../Utils/Endpoint';
import moment from 'moment';

export default class DashboardHelper {
    constructor(self) {
        this.self = self
    }
    UserData = async () => {
        this.self.setState({ isloading: true })
        console.log("deviceihhhnfo")
        const EmpId = await AsyncStorage.getItem('EmpId')
        const jsonValueClientID = await AsyncStorage.getItem('ClientId')
        await axios.post(Endpoint.baseUrl + Endpoint.PersonalDetail, {
            "EmpId": EmpId,

            "ClientId": JSON.parse(jsonValueClientID),
        })
            .then(async response => {
                console.log("gdfgdfhdfhdf", response.data)
                // await AsyncStorage.setItem('Name', response.data.FirstName)

            })
            .catch(function (error) {
                alert("Please Enter Valid Credentials")
                // alert(response.data.message)
                // console.warn("guggsgggdsy", error);
            })
    }
    ClockInOut = async () => {
        this.self.setState({ isloading: true })
        console.log("deviceihhhnfo")
        const EmpId = await AsyncStorage.getItem('EmpId')
        const jsonValueClientID = await AsyncStorage.getItem('ClientId')
        const jsonValue = await AsyncStorage.getItem('UserId')

        await axios.post(Endpoint.baseUrl + Endpoint.ClockInOut, {
            "EmpId": EmpId,
            "longtitude": this.self.state.longtitude,
            "lattitude": this.self.state.lattitude,
            "GetMasterDBName": "abc",
            "UserId": jsonValue,
            "FileUrl": "abc",
            "Comment": "108",
            "IsAutoClockIn": "true",
            "ClientId": JSON.parse(jsonValueClientID),
        })
            .then(async response => {
                console.log("ClockIn", response.data)
                // await AsyncStorage.setItem('Name', response.data.FirstName)

            })
            .catch(function (error) {
                // alert("Please Enter Valid Credentials")
                alert(response.data.message)
                // console.warn("guggsgggdsy", error);
            })
    }
    
    track = async () => {
        this.self.setState({ isloading: true })
        console.log("clockk")
        const EmpId = await AsyncStorage.getItem('EmpId')
        const jsonValueClientID = await AsyncStorage.getItem('ClientId')
        const jsonValue = await AsyncStorage.getItem('UserId')

        await axios.post(Endpoint.baseUrl + Endpoint.track, {
            "EmpId": EmpId,
            "longtitude": this.self.state.longtitude,
            "lattitude": this.self.state.lattitude,
            "TrackDateTime": new Date().toISOString(),
            "UserId": jsonValue,
            "GPSStatus": "abc",
            "Battery": "108",
            "ClientId":JSON.parse(jsonValueClientID),
        })
            .then(async response => {
                console.log("ClockIn...", response.data)
                this.self.toggleStopwatch();
                this.self.setState({ play: true })
                // await AsyncStorage.setItem('Name', response.data.FirstName)

            })
            .catch(function (error) {
                // alert("Please Enter Valid Credentials")
                alert(response.data.message)
                // console.warn("guggsgggdsy", error);
            })
    }

    GetImageProfile= async () => {
        this.self.setState({ isloading: true })
        console.log("clockk")
        const EmpId = await AsyncStorage.getItem('EmpId')
        const AuthToken = await AsyncStorage.getItem('AuthToken')

        const jsonValueClientID = await AsyncStorage.getItem('ClientId')
        // const jsonValue = await AsyncStorage.getItem('UserId')

        await axios.post(Endpoint.baseUrlTask + Endpoint.GetImageProfile, {
            "EmpId": EmpId,
            "ClientId":JSON.parse(jsonValueClientID),
        }, {
            headers:  {
            "token":AuthToken,
            "ClientId":JSON.parse(jsonValueClientID),

    
        },
    })
            .then(async response => {
                console.log("imagegegege...", response.data)
this.self.setState({
    ImagePicUrl:response.data.Table[0].DocumentUrl
})
             
            })
            .catch(function (error) {
                // alert("Please Enter Valid Credentials")
                alert(response.data.message)
                // console.warn("guggsgggdsy", error);
            })
    }

}
