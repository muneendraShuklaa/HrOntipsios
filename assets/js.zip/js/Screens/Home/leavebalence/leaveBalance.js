import React, {Component} from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  FlatList,
  StyleSheet,
  Image,
  ImageBackground,
} from 'react-native';
import {WebView} from 'react-native-webview';
import utils from '../../../Utils';
import {Header} from '../../../Components/Header';
import {withMyHook} from '../../../Utils/Dark';
import {vh, vw, normalize} from '../../../Utils/dimentions';
import LeavedHelper from './helper';
import {SafeAreaView} from 'react-native-safe-area-context';
import moment from 'moment';

class leavebalance extends Component {
  constructor(props) {
    super(props);
    this.state = {
      ViewCard: false,
      LeaveRecord: [],
      approvedIndex: '-1',

      cardDeatils: [
        {
          Name: 'Sick Leaves',
          title: '12',
          date: '12Feb - 16Feb',
          Icon: utils.icons.Vectorgreen,
          Status: utils.icons.Approve,
        },
      ],
      LeaveDeatils: [
        {
          Type: 'AL',
          Total: '12',
        },
        {
          Type: 'CL',
          Total: '6',
        },
        {
          Type: 'CL',
          Total: ' 2',
        },
      ],
    };
    this.helper = new LeavedHelper(this);
  }

  componentDidMount() {
    this.helper.LeaveStatus();
    this.helper.GetLeaveBalance();
  }
  render() {
    return (
      <ImageBackground
        source={utils.icons.backImage}
        style={{flex: 1, height: '100%', width: '100%'}}>
        <TouchableOpacity
          onPress={() => {
            this.props.navigation.goBack();
          }}
          style={{flexDirection: 'row', padding: 20, marginTop: 20}}>
          <Image
            source={utils.icons.Back}
            style={{alignSelf: 'center', marginRight: 10, tintColor: '#fff'}}
          />
          <Text
            style={[
              utils.fontStyle.FontFamilymachoB,
              {color: '#fff', fontSize: normalize(26)},
            ]}>
            Leave Request
          </Text>
        </TouchableOpacity>
        <View style={{height: 140}}>
          <FlatList
            horizontal
            style={{width: '100%', marginTop: 20, marginLeft: '10%'}}
            showsHorizontalScrollIndicator={false}
            data={this.state.LeaveDeatils}
            keyExxtractor={(item, index) => index.toString}
            renderItem={({item, index}) => this.renderItemLeave(item, index)}
          />
        </View>

        <FlatList
          extraData={this.state.approvedIndex}
          style={{padding: 20}}
          showsHorizontalScrollIndicator={false}
          data={this.state.LeaveRecord}
          keyExxtractor={(item, index) => index.toString}
          renderItem={({item, index}) => this.renderItem(item, index)}
        />
      </ImageBackground>
    );
  }

  renderItem(item, index) {
    return (
      <View
        style={{
          height: 'auto',
          width: '98%',
          paddingBottom: vh(10),
          marginTop: vh(5),
          justifyContent: 'center',
          alignSelf: 'center',
        }}>
        <View style={styles.shadowView}>
          {this.state.approvedIndex == index ? (
            <TouchableOpacity
              style={{alignSelf: 'center'}}
              onPress={() => {
                this.setState({ViewCard: false, approvedIndex: index});
              }}>
              <View
                style={{
                  flexDirection: 'row',
                  marginTop: 10,
                  paddingBottom: 10,
                }}>
                {/* <View style={{ alignSelf: 'center' }}>
                            <Image source={item.Icon} style={{ height: vh(30), width: vw(30), marginLeft: 10 }} />
                        </View> */}
                <View style={{alignSelf: 'center'}}>
                  <Text
                    style={[
                      styles.Title,
                      utils.fontStyle.TextSemiBold,
                      {
                        width: vw(230),
                        marginLeft: 15,
                        alignSelf: 'center',
                        fontSize: 16,
                      },
                    ]}>
                    {item.LeaveName}
                  </Text>
                  <Text
                    style={[
                      styles.Title,
                      utils.fontStyle.FontFamilyRegular,
                      {
                        width: vw(230),
                        marginLeft: 15,
                        alignSelf: 'center',
                        fontSize: 12,
                      },
                    ]}>
                    {moment(item.ToDate).format('ll')}-
                    {moment(item.FromDate).format('ll')}
                  </Text>
                </View>
                {/* <Image
                        source={item.Status}
                        style={{ alignSelf: 'center', marginRight: 10,  }}
                    /> */}
                {item.Status == 'Approved' ? (
                  <Image
                    source={utils.icons.Approve}
                    style={{alignSelf: 'center', marginRight: 10}}
                  />
                ) : (
                  <View>
                    {item.Status == 'Rejected' ? (
                      <Image
                        source={utils.icons.red}
                        style={{alignSelf: 'center', marginRight: 10}}
                      />
                    ) : (
                      <Image
                        source={utils.icons.Vectoyellooo}
                        style={{alignSelf: 'center', marginRight: 10}}
                      />
                    )}
                  </View>
                )}
              </View>
              <View>
                <View style={{borderTopWidth: 1, borderTopColor: '#cacaca'}}>
                  <Text
                    style={[
                      styles.Title,
                      utils.fontStyle.TextSemiBold,
                      {
                        width: vw(180),
                        marginTop: 10,
                        marginLeft: 15,
                        fontSize: 16,
                      },
                    ]}>
                    Reason:
                  </Text>
                  <Text
                    style={[
                      styles.Title,
                      utils.fontStyle.FontFamilyRegular,
                      {width: vw(360), marginLeft: 15, fontSize: 12},
                    ]}>
                    {item.Comments}
                  </Text>
                </View>
                <View style={{marginTop: 10, marginBottom: 10}}>
                  <Text
                    style={[
                      styles.Title,
                      utils.fontStyle.TextSemiBold,
                      {width: vw(180), marginLeft: 15, fontSize: 16},
                    ]}>
                    HR Comment:
                  </Text>
                  <Text
                    style={[
                      styles.Title,
                      utils.fontStyle.FontFamilyRegular,
                      {width: '70%', marginLeft: 15, fontSize: 12},
                    ]}>
                    {item.Status}
                  </Text>
                </View>
              </View>
            </TouchableOpacity>
          ) : (
            <TouchableOpacity
              style={{alignSelf: 'center'}}
              onPress={() => {
                this.setState({ViewCard: true, approvedIndex: index});
              }}>
              <View
                style={{
                  flexDirection: 'row',
                  marginTop: 10,
                  paddingBottom: 10,
                }}>
                {/* <View style={{ alignSelf: 'center' }}>
                            <Image source={item.Icon} style={{ height: vh(30), width: vw(30), marginLeft: 10 }} />
                        </View> */}
                <View style={{alignSelf: 'center'}}>
                  <Text
                    style={[
                      styles.Title,
                      utils.fontStyle.TextSemiBold,
                      {
                        width: vw(230),
                        marginLeft: 15,
                        alignSelf: 'center',
                        fontSize: 16,
                      },
                    ]}>
                    {item.LeaveName}
                  </Text>
                  <Text
                    style={[
                      styles.Title,
                      utils.fontStyle.FontFamilyRegular,
                      {
                        width: vw(230),
                        marginLeft: 15,
                        alignSelf: 'center',
                        fontSize: 12,
                      },
                    ]}>
                    {moment(item.ToDate).format('ll')}-
                    {moment(item.FromDate).format('ll')}
                  </Text>
                </View>
                {item.Status == 'Approved' ? (
                  <Image
                    source={utils.icons.Approve}
                    style={{alignSelf: 'center', marginRight: 10}}
                  />
                ) : (
                  <View>
                    {item.Status == 'Rejected' ? (
                      <Image
                        source={utils.icons.red}
                        style={{alignSelf: 'center', marginRight: 10}}
                      />
                    ) : (
                      <Image
                        source={utils.icons.Vectoyellooo}
                        style={{alignSelf: 'center', marginRight: 10}}
                      />
                    )}
                  </View>
                )}
                {/* <Image
                        source={utils.icons.Vector}
                        style={{ alignSelf: 'center', marginRight: 10,  }}
                    /> */}
              </View>
            </TouchableOpacity>
          )}
        </View>
      </View>
    );
  }
  renderItemLeave(item, index) {
    return (
      <View style={{height: 'auto', width: 'auto'}}>
        <View style={{flexDirection: 'row'}}>
          <View style={{height: 100, width: 100}}>
            <View
              style={{
                backgroundColor: '#fff',
                height: 65,
                width: 65,
                borderRadius: 50,
                justifyContent: 'center',
                alignSelf: 'center',
              }}>
              <Text
                style={{
                  textAlign: 'center',
                  fontSize: 28,
                  color: utils.color.textColorheading,
                  fontWeight: 'bold',
                }}>
                {item.Total}
              </Text>
            </View>
            <Text
              style={{
                textAlign: 'center',
                fontSize: 16,
                fontWeight: 'bold',
                color: '#fff',
                marginTop: 5,
              }}>
              {item.Type}
            </Text>
          </View>
        </View>
      </View>
    );
  }
}
export const LeaveBalance = withMyHook(leavebalance);
const styles = StyleSheet.create({
  Title: {
    color: '#000',
  },
  shadowView: {
    height: 'auto',
    width: '100%',
    justifyContent: 'space-between',
    borderRadius: 10,
    backgroundColor: '#fff',
    flexDirection: 'row',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.23,
    shadowRadius: 2.62,
    elevation: 4,
  },
});
