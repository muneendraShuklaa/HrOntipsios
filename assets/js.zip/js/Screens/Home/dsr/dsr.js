import React, { Component } from 'react';
import { View, Text, TouchableOpacity, FlatList, StyleSheet,Image } from 'react-native';
import { WebView } from 'react-native-webview'
import utils from '../../../Utils';
import { Header } from "../../../Components/Header"
import { withMyHook } from "../../../Utils/Dark"
import { vh, vw, normalize } from '../../../Utils/dimentions';

import { SafeAreaView } from 'react-native-safe-area-context';

class dsr extends Component {
  constructor(props) {
    super(props)
    this.state = {
        cardDeatils: [
              
            {
                date: 'Apr 22, 2023',
                title: 'Mon',
                hour:"9"
            },
            {
                date: 'Mar 22, 2023',
                title: 'Wed',
                hour:"9.5"

            },
            {
                date: 'Mar 22, 2023',
                title: 'Tue',
                hour:"12"

            },   {
                date: 'Apr 22, 2023',
                title: 'Mon',
                hour:"9"
            },
            {
                date: 'Mar 22, 2023',
                title: 'Wed',
                hour:"9.5"

            },
            {
                date: 'Mar 22, 2023',
                title: 'Tue',
                hour:"12"

            },
            {
                date: 'Apr 22, 2023',
                title: 'Mon',
                hour:"9"
            },
            {
                date: 'Mar 22, 2023',
                title: 'Wed',
                hour:"9.5"

            },
            {
                date: 'Mar 22, 2023',
                title: 'Tue',
                hour:"12"

            },
            {
                date: 'Apr 22, 2023',
                title: 'Mon',
                hour:"9"
            },
            {
                date: 'Mar 22, 2023',
                title: 'Wed',
                hour:"9.5"

            },
            {
                date: 'Mar 22, 2023',
                title: 'Tue',
                hour:"12"

            },
        ]
     
    }
  }
  render() {
    return (
      <SafeAreaView style={{ flex: 1, backgroundColor: utils.color.HeaderColor }}>
        <View style={{ flex: 1, backgroundColor: '#fff', }}>
          {/* <StatusBar
                hidden={false}
                backgroundColor={utils.color.HeaderColor}
            /> */}
          <Header
            title="Daily Status Report"
            lefticon={utils.icons.Back} leftFunction={() => { this.props.navigation.goBack() }}
          // rightIcon={utils.icons.splashLogo} rightFunctionality={() => { this.props.navigation.navigate("Profile") }}
          />
 {/* <FlatList
                                style={{ marginTop: vh(10), height:"100%" ,paddingLeft:20,paddingRight:20}}
                                showsHorizontalScrollIndicator={false}
                                data={this.state.cardDeatils}
                                keyExxtractor={(item, index) => index.toString}
                                renderItem={({ item, index }) => this.renderItem(item, index)}
                            /> */}
                            






          

        </View>
      </SafeAreaView>
    );
  }
  renderItem(item, index) {
    return (
        <View style={{ height: 60, width: "98%",marginBottom: vh(10), justifyContent: 'center', alignSelf: 'center' }}>
            <View style={styles.shadowView}>
                {/* <TouchableOpacity style={{alignSelf:'center'}} onPress={()=>{this.props.navigation.navigate("LiveLocation")}}> */}
                    
                    <View style={{ flexDirection:'row',justifyContent:'space-between'  }}>
                       <View style={{height:60,borderTopLeftRadius:10,borderBottomLeftRadius:10, width:"25%",backgroundColor:utils.color.HeaderColor,justifyContent:'center'}}>
                       <Text style={[styles.Title, utils.fontStyle.TextSemiBold,{alignSelf:"center", fontSize:18,color:utils.color.TextColorWhite }]}>{item.title}</Text>
                       </View>
                       <View style={{height:60,justifyContent:'center',width:"50%",}}>
                       <Text style={[styles.Title, utils.fontStyle.TextSemiBold,{alignSelf:"center", fontSize:16,color:utils.color.textColor }]}>{item.date}</Text>

                       </View>

                       <View style={{height:60,borderTopRightRadius:10,borderBottomRightRadius:10, width:"25%",backgroundColor:utils.color.HeaderColor,justifyContent:'center'}}>
                       <Text style={[styles.Title, utils.fontStyle.TextSemiBold,{alignSelf:"center", fontSize:18,color:utils.color.TextColorWhite }]}>{item.hour}</Text>
                       </View>
                    </View>

                {/* </TouchableOpacity> */}
            </View>
        
       </View>

    )
}
}
export const DSR = withMyHook(dsr)
const styles = StyleSheet.create({
    Title: {
        color: "#000",
    },
    shadowView: {
        height: vh(70), width: "100%", 
        borderRadius: 10,
        backgroundColor: '#fff', justifyContent:'center',
        shadowColor: "#000",
        shadowOffset: {
            width: 0,
            height: 2,
        },
        shadowOpacity: 0.23,
        shadowRadius: 2.62,
        elevation: 4,
    }
});
