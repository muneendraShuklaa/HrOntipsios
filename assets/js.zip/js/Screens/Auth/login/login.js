import React, {Component} from 'react';
import {
  Text,
  View,
  StyleSheet,
  Image,
  TouchableOpacity,
  TextInput,
  ActivityIndicator,
  ImageBackground,
  ScrollView,
  StatusBar,
} from 'react-native';
import {withMyHook} from '../../../Utils/Dark';
import {vh, vw, normalize} from '../../../Utils/dimentions';
import utils from '../../../Utils';
import SignInHelper from './helper';
import AsyncStorage from '@react-native-async-storage/async-storage';

// import Geolocation from '@react-native-community/geolocation';
import CountryPicker, {DARK_THEME} from 'react-native-country-picker-modal';
// import{ firebase } from '@react-native-firebase/auth';
// import { AppOpenAd, InterstitialAd, BannerAdSize, BannerAd, TestIds } from "react-native-google-mobile-ads";
// import { AppOpenAd, InterstitialAd, BannerAdSize, BannerAd, TestIds } from "react-native-google-mobile-ads";

import Icon from 'react-native-vector-icons/FontAwesome';
import Utils from '../../../Utils';
// navigator.geolocation = require('@react-native-community/geolocation');

Icon.loadFont();
class login extends Component {
  constructor(props) {
    super(props);
    this.state = {
      email: 'jht10047',
      password: '123@Sitaram',
      isloading: false,
      Active: '',
      secureTextEntry: true,
      address: '',
      AuthToken: '',
      // Title:this.props.route.params.Title
    };
    this.helper = new SignInHelper(this);
  }
  async componentDidMount() {
    this.helper.AuthCheck();
    this.AuthCheck();
    let AuthToken = await AsyncStorage.getItem('AuthToken');
    this.setState({
      AuthToken: AuthToken,
    });
  }
  AuthCheck = async () => {
    let Active = await AsyncStorage.getItem('IsAuthenticated');
    let Answer1 = await AsyncStorage.getItem('Answer1');

    if (Active == 'true' && Answer1 == 'hrontips') {
      this.props.navigation.navigate('bottomTabBarr');
    }
    if (Active == 'true' && Answer1 == 'ejoin') {
      this.props.navigation.navigate('WEJoin');
    }
  };
  getLocationUser = async () => {
    RNLocation.configure({
      distanceFilter: 5.0,
    });

    RNLocation.requestPermission({
      ios: 'whenInUse',
      android: {
        detail: 'coarse',
      },
    }).then(granted => {
      if (granted) {
        RNLocation.getLatestLocation({timeout: 60000}).then(latestLocation => {
          var NY = {
            lat: latestLocation.latitude,
            lng: latestLocation.longitude,
          };
          Geocoder.geocodePosition(NY)
            .then(res => {
              this.setState({address: res[0].locality});
            })
            .catch(err => console.log(err));

          this.setState({
            latitude: latestLocation.latitude,
            longitude: latestLocation.longitude,
            current_latitude: latestLocation.latitude,
            current_longitude: latestLocation.longitude,
          });
        });
      }
    });
  };
  validateNLogin = () => {
    if (this.state.email == false) {
      alert('Please enter your Email-Id.');
    } else {
      if (this.state.password == '') {
        alert('Please enter your password.');
      } else {
        // this.props.navigation.navigate("Dashboard")
        this.helper.signIN();
      }
    }
  };
  render() {
    return (
      <View style={{flex: 1, backgroundColor: '#ffff', height: '100%'}}>
        <StatusBar
          hidden={false}
          backgroundColor={utils.color.HeaderColor}
          translucent
          barStyle="light-content"
        />
        <ScrollView>
          <ImageBackground
            imageStyle={{}}
            style={{
              height: 490,
              width: '100%',
              alignSelf: 'center',
              marginTop: -20,
            }}
            source={utils.icons.loginback}>
            {/* <View  style={{backgroundColor:'#3083EF',opacity:0.5,height:480}}>
        </View> */}
          </ImageBackground>

          {/* <ImageBackground source={utils.icons.backImage} style={{ height: "70%", width: '100%',  }} >
             </ImageBackground> */}

          <View
            style={{
              backgroundColor: '#ffff',
              borderTopLeftRadius: 40,
              borderTopEndRadius: 40,
              paddingBottom: 60,
              marginTop: -40,
              paddingLeft: 30,
              paddingRight: 30,
              justifyContent: 'center',
            }}>
            {/* <Image style={{ height: vh(130), width: vw(320), alignSelf: 'center', marginTop: 140 }} source={utils.icons.Logo}></Image> */}

            <Image
              style={{
                height: 70,
                width: 250,
                alignSelf: 'center',
                marginTop: vw(20),
              }}
              source={utils.icons.Logo}></Image>
            {/* <Text>{this.state.Title}</Text> */}
            <View
              style={[
                styles.mobileText1,
                {
                  flexDirection: 'row',
                  alignItems: 'center',
                  marginTop: vh(40),
                  borderColor: this.props.themeColor.bordercolor,
                },
              ]}>
              <Image
                style={{
                  height: vh(30),
                  width: vw(30),
                  tintColor: '#3083EF',
                  alignSelf: 'center',
                  marginRight: vw(2),
                }}
                source={utils.icons.email}></Image>
              <TextInput
                placeholder={utils.Strings.EnterNumber}
                placeholderTextColor="grey"
                returnKeyType="done"
                keyboardType="email-address"
                allowFontScaling={false}
                // onBlur={() => this.state.validMail == false && this.setState({ Mobile: '' })}
                onChangeText={val => this.setState({email: val})}
                value={this.state.email}
                maxLength={30}
                style={[
                  styles.mobileTextInput,
                  utils.fontStyle.FontFamilyRegular,
                  {color: '#000'},
                ]}></TextInput>
            </View>
            <View
              style={[
                styles.mobileText1,
                {
                  flexDirection: 'row',
                  alignItems: 'center',
                  marginTop: vh(20),
                  borderColor: this.props.themeColor.bordercolor,
                },
              ]}>
              <Image
                style={{
                  height: vh(30),
                  width: vw(30),
                  tintColor: '#3083EF',
                  alignSelf: 'center',
                  marginRight: vw(2),
                }}
                source={utils.icons.padlock}></Image>
              <TextInput
                placeholder={utils.Strings.password}
                placeholderTextColor="grey"
                returnKeyType="done"
                secureTextEntry={this.state.secureTextEntry}
                allowFontScaling={false}
                // onBlur={() => this.state.validMail == false && this.setState({ Mobile: '' })}
                onChangeText={val => this.setState({password: val})}
                value={this.state.password}
                maxLength={16}
                style={[
                  styles.mobileTextInput,
                  utils.fontStyle.FontFamilyRegular,
                  {color: '#000'},
                ]}></TextInput>
              {this.state.secureTextEntry === true ? (
                <TouchableOpacity
                  onPress={() => this.setState({secureTextEntry: false})}
                  style={{justifyContent: 'center'}}>
                  <Image
                    source={utils.icons.eye}
                    style={{
                      height: vh(30),
                      width: vw(30),
                      tintColor: '#3083EF',
                      alignSelf: 'center',
                      marginRight: vw(2),
                    }}
                  />
                </TouchableOpacity>
              ) : (
                <TouchableOpacity
                  onPress={() => this.setState({secureTextEntry: true})}
                  style={{justifyContent: 'center'}}>
                  <Image
                    source={utils.icons.hidden}
                    style={{
                      height: vh(30),
                      width: vw(30),
                      tintColor: '#3083EF',
                      alignSelf: 'center',
                      marginRight: vw(2),
                    }}
                  />
                </TouchableOpacity>
              )}
            </View>
            {/* {this.state.AuthToken!==null?
          <Text>Please Ender Valid Credentials</Text>
          : */}
            {/* null}
          <Text>{this.state.AuthToken}</Text> */}
            <View
              style={{
                flexDirection: 'row',
                justifyContent: 'flex-end',
                marginTop: 10,
              }}>
              <TouchableOpacity
                onPress={() => {
                  this.props.navigation.navigate('Forgot');
                }}>
                {/* <WebView source={{ uri: 'https://reactnative.dev/' }} /> */}
                <Text
                  style={[
                    utils.fontStyle.FontFamilyBold,
                    {color: utils.color.ClorText, fontSize: 16},
                  ]}>
                  Forgot Password ?
                </Text>
              </TouchableOpacity>
            </View>

            <View>
              <TouchableOpacity
                style={[styles.ButtonView, {}]}
                onPress={() => {
                  // this.props.navigation.navigate("bottomTabBar");
                  // this.handleSendCode(), { Email: this.state.email, Password: this.state.password }
                  this.validateNLogin();
                }}>
                <Text
                  style={[
                    utils.fontStyle.FontFamilyExtraBold,
                    {color: utils.color.TextColorWhite},
                    {textAlign: 'center', fontSize: 22, fontWeight: 'bold'},
                  ]}>
                  {utils.Strings.login}
                </Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={() => {
                  this.props.navigation.navigate('WEJoin');
                }}>
                <Text>Ejoin</Text>
              </TouchableOpacity>
            </View>
          </View>
        </ScrollView>
      </View>
    );
  }
}
export const Login = withMyHook(login);
const styles = StyleSheet.create({
  Image: {
    width: vw(50),
    tintColor: utils.color.ButtonAll,
    height: Platform.OS === 'ios' ? vh(50) : vh(50),
    justifyContent: 'center',
    alignSelf: 'center',
  },
  mobileText: {
    height: vh(50),
    width: '80%',
    fontSize: normalize(16),
    paddingLeft: vw(20),
  },

  mobileText1: {
    height: 'auto',
    // marginTop: vh(50),
    width: '100%',
    backgroundColor: '#e9efff',
    fontSize: normalize(18),
    paddingLeft: vw(20),
    borderRadius: normalize(10),
    // backgroundColor: '#fff',
    // borderColor: 'red',
    // borderWidth: 0.5,
    borderRadius: 10,
    flexDirection: 'row',
    // shadowColor: "#000",
    // shadowOffset: {
    //   width: 0,
    //   height: 2,
    // },
    // shadowOpacity: 0.23,
    // shadowRadius: 2.62,
    // elevation: 4,
  },
  mobileTextInput: {
    paddingLeft: vw(15),
    height: 'auto',
    padding: 15,
    width: '80%',
    alignSelf: 'center',
  },
  ButtonView: {
    backgroundColor: '#3083EF',
    height: vh(60),
    width: '100%',
    borderRadius: vw(30),
    marginTop: vh(30),
    alignSelf: 'center',
    justifyContent: 'center',
  },
});
