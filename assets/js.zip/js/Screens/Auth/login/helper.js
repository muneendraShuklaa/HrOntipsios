import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';
import Endpoint from '../../../Utils/Endpoint';
export default class signInHelper {
  constructor(self) {
    this.self = self;
  }

  AuthCheck = async () => {
    let Active = await AsyncStorage.getItem('IsAuthenticated');
    let Answer1 = await AsyncStorage.getItem('Answer1');

    if (Active == 'true' && Answer1 == 'hrontips') {
      this.props.navigation.navigate('bottomTabBarr');
    }
    if (Active == 'true' && Answer1 == 'ejoin') {
      this.props.navigation.navigate('WEJoin');
    }
  };

  signIN = async () => {
    // this.self.setState({ isloading: true })
    console.log('deviceihhhnfo');
    await axios
      .post(Endpoint.baseUrl + Endpoint.Login, {
        username: this.self.state.email,
        password: this.self.state.password,
        // "username":  "JHT10088",
        // "password":"amit@098",
        IMEI: '',
        DeviceId: '',
        DomainName: 'MobileApplicationLogin',
        grant_type: '',
      })
      .then(async response => {
        // this.self.setState({isloading: false});
        //     {response.data.message =="User logged in successfully."?
        //     null
        //     :
        //     // alert(response.data.message)
        // }

        console.log('dataaaaassdsfs', response.data);
        console.log('loginTokennnnn', response.data.Token);
        await AsyncStorage.setItem('Name', response.data.FirstName);
        await AsyncStorage.setItem('Department', response.data.DesignationId);
        await AsyncStorage.setItem('AuthToken', response.data.AuthToken);
        await AsyncStorage.setItem('Answer1', response.data.Answer1);

        await AsyncStorage.setItem(
          'ClientId',
          response.data.ClientId.toString(),
        );
        await AsyncStorage.setItem('EmpId', response.data.EmpId);
        await AsyncStorage.setItem('UserId', response.data.UserId.toString());
        await AsyncStorage.setItem(
          'IsAuthenticated',
          response.data.IsAuthenticated.toString(),
        );
        await AsyncStorage.setItem(
          'UserType',
          response.data.UserType.toString(),
        );

        this.self.setState({isloading: false});
        this.self.getLocationUser();
        // setTimeout(() => {
        //   this.AuthCheck();
        // }, 2000);
        this.self.props.navigation.navigate('bottomTabBarr', {});

        // else {
        //     this.self.setState({ isloading: false })
        //     alert(response.data.message)
        // }
      })
      .catch(function (error) {
        console.log(error);
        alert('Please Enter Valid Credentials');
        // alert(response.data.message)
        // console.warn("guggsgggdsy", error);
      });
  };
}
