export default {
  baseUrl: 'https://prodapi.hrontips.com/',
  baseUrlTask: 'https://prodapi2.hrontips.com/',
  // baseUrlTime: "https://b2b.hrontips.com/api/ScheduleController/",

  //loginApi
  Login: 'API/Account/AuthenticateUser',
  PersonalDetail: 'API/Home/GetDataPesionaldetails',
  ClockInOut: 'API/Home/InsertUpdateClockInAndOut ',
  track: 'API/Home/InsertEmpGeoTrack',
  leaveStatus: 'API/Home/GetEmployeePendingLeaveApproval',
  UserPersonalDetail: 'API/Home/GetDatajobdetails',
  LeaveApproval: 'API/Home/GetPendingLeaveApproval_V2',
  statusLeave: 'API/Home/ApproveRejectLeave',
  GetLeaveBalance: 'API/Home/GetLeaveBalance',
  GetLeaveType: 'API/Home/GetLeaveType',
  GetImageProfile: 'API/UploadPicture/GetUploadPicture',
  EjoinData: 'API/Ejoin/GeteJoinEmployeeDocumentView',
  UploadDoc: 'API/Ejoin/eJoinEmployeeDocumentUpload',
  DocList: 'API/Ejoin/GeteJoinUploadEmployeeDocumentView',
};
