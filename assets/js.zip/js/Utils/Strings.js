export default {
    //////header
    title1: "Login",
    title2: "Welcome To HrOnTips",
    subtacount: " By creating an account, you agree to our",
    terms: "Privacy Policy",
    and: "and",
    Title: "Garrity",
    login: "Login",
    EnterNumber: "Enter Your Id",
password:"Enter Your Password",
Fotgot:"Forgot-Password?",



///Profile
Profile:"My Profile",
timecard:"Time Cards",
Today:"Today's Schedules",
myTeam:"Team Tracker",
UploadImage:"UploadImage",
info:"Information",
Notes:"Notes",
save:"Save Time Card",
TimeCard:'Time Card',
Team:"My Team",
enternote:"Mention the details of your leaves."
}