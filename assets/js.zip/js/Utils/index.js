import {color} from './color'
import Strings from './Strings'
import icons from './icons'
import fontStyle from './fontStyle'
// import AlertDialog from "./alert"
export default {
    Strings,
    icons,
    color,
    fontStyle,
    // AlertDialog
}