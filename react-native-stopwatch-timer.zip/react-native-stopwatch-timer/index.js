module.exports = {
  Stopwatch: require("./lib/stopwatch.js").default,
  Timer: require("./lib/timer.js").default
};
